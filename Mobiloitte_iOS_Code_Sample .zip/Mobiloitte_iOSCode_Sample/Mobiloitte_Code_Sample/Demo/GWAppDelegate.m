//
//  GWAppDelegate.m
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWAppDelegate.h"
#import "Reachability.h"

@implementation GWAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
//  Override point for customization after application launch.
    
//  starting reachability notifier
    [self checkReachability];
    
//  enabling network indicator
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    
//  registering for push notification
    [[UIApplication sharedApplication] registerForRemoteNotificationTypes:UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound|UIRemoteNotificationTypeAlert ];
    
        
    GWRearViewController *rearVC = [[GWRearViewController alloc] initWithNibName:@"GWRearViewController" bundle:nil];
    GWHomeVC *homeVC = [[GWHomeVC alloc] initWithNibName:@"GWHomeVC" bundle:nil];
    
    GWNavigationController *frontNavigationController = [[GWNavigationController alloc] initWithRootViewController:homeVC];
	
	self.revealController = [[JASidePanelController alloc] init];
    self.revealController.shouldDelegateAutorotateToVisiblePanel = NO;

    self.revealController.leftPanel = rearVC;
    self.revealController.centerPanel = frontNavigationController;

    
    [self.window setRootViewController:self.revealController];
    self.window.backgroundColor = [UIColor whiteColor];
    
//    [GAI sharedInstance].debug = NO;
//    [GAI sharedInstance].dispatchInterval = 1;
//    [GAI sharedInstance].trackUncaughtExceptions = YES;
//    [[GAI sharedInstance] trackerWithTrackingId:TRACKING_ID];
    
    [self.window makeKeyAndVisible];
    return YES;
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url{
    NSString *text = [url absoluteString];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Text" message:text delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alertView show];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{

    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];

    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

-(void)checkReachability{
    
    Reachability * reach = [Reachability reachabilityForInternetConnection];
    self.isReachable = [reach isReachable];
    
    reach.reachableBlock = ^(Reachability * reachability)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.isReachable = YES;
        });
    };
    
    reach.unreachableBlock = ^(Reachability * reachability)
    {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.isReachable = NO;
        });
    };
    
    [reach startNotifier];
}

// push notification delgate methods
- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken{

    NSString *mytoken = [[deviceToken description] stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
//    NSLog(@"device token %@",[mytoken stringByReplacingOccurrencesOfString:@" " withString:@""]);
    [[NSUserDefaults standardUserDefaults] setObject:[mytoken stringByReplacingOccurrencesOfString:@" " withString:@""] forKey:K_DEVICE_TOKEN];
}

- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error{
//	NSLog(@"Failed to get token, error: %@", error);
}

-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);

    NSString *notifCount = [NSString stringWithFormat:@"%d",[[[userInfo objectForKey:@"aps"] objectForKey:@"badge"] integerValue]];
    [kDef setObject:notifCount forKey:kNotificationCount];

    [[NSNotificationCenter defaultCenter] postNotificationName:k_Notification_Recieved object:nil];
}


@end
