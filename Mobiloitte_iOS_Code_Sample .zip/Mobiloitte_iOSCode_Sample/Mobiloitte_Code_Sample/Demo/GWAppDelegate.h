//
//  GWAppDelegate.h
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Macros.h"

@interface GWAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) JASidePanelController *revealController ;

@property (nonatomic, assign) BOOL isReachable;

@end
