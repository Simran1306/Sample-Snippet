//
//  main.m
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GWAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([GWAppDelegate class]));
    }
}
