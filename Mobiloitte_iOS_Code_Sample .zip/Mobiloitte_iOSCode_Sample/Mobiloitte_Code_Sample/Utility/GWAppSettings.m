//
//  GWAppSettings.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWAppSettings.h"

@implementation GWAppSettings

+ (GWAppSettings *)sharedInstance
{
    static dispatch_once_t once;
    static GWAppSettings *sharedInstance;
    dispatch_once(&once, ^{
        sharedInstance = [[GWAppSettings alloc] init];
    });
    return sharedInstance;
}

- (id)init {
    self = [super init];
    if (self) {
        _app_blueColor      = [UIColor colorWithRed:10.0/255.0 green:144.0/255.0 blue:208.0/255.0 alpha:1.00f];
        _app_greenColor     = [UIColor colorWithRed:0.0/255.0 green:179.0/255.0 blue:134.0/255.0 alpha:1.00f];
        _app_darkGreyColor  = [UIColor colorWithRed:132.0/255.0 green:132.0/255.0 blue:132.0/255.0 alpha:1.0];
        _app_redColor       = [UIColor colorWithRed:245.0/255.0 green:94.0/255.0 blue:78.0/255.0 alpha:1.0];
        _app_lightGreyColor = [UIColor colorWithRed:248.0/255.0 green:248.0/255.0 blue:248.0/255.0 alpha:0.925];

    }
    return self;
}

-(UIFont*)app_HelveticaRegularWithSize:(CGFloat)size{
    return [UIFont fontWithName:@"Helvetica" size:size];

}
-(UIFont*)app_HelveticaThinWithSize:(CGFloat)size{
    return [UIFont fontWithName:@"HelveticaNeue-Light" size:size];

}
-(UIFont*)app_HelveticaBoldWithSize:(CGFloat)size{
    return [UIFont fontWithName:@"Helvetica-Bold" size:size];
}

-(UIFont*)app_HelveticaNeueMediumWithSize:(CGFloat)size{
    return [UIFont fontWithName:@"HelveticaNeue-Medium" size:size];
}

@end
