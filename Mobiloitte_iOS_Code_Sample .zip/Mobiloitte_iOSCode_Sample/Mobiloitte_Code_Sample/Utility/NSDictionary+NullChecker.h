//
//  NSDictionary+NullChecker.h
//  Demo!
//
//  Created by Apoorve Tyagi on 10/30/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (NullChecker)

-(id)objectForKeyNotNull:(id)object expectedObj:(id)obj;

@end
