//
//  GWComposer.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/21/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWComposer.h"

static GWComposer *sharedInstance;

@implementation GWComposer

+(GWComposer *)sharedManager {
    
    static dispatch_once_t pred;
    
    dispatch_once(&pred, ^{
        sharedInstance = [[GWComposer alloc] init];
    });
    
    return sharedInstance;
}

#pragma mark - Instamce methods for mail composer

-(void)sendMailWithSubject:(NSString*)subject andBody:(NSString*)body recepients:(NSArray*)recepients{
    Class mailClass = (NSClassFromString(@"MFMailComposeViewController"));
    if (mailClass != nil)
    {
        // We must always check whether the current device is configured for sending emails
        if ([mailClass canSendMail])
        {
            [self displayMailComposerSheetWithSubject:subject andBody:body recepients:recepients];
        }
        else
        {
            NSString *recipients = nil;
            if ([recepients count]) {
               recipients =[NSString stringWithFormat:@"mailto:%@?subject=%@",[recepients objectAtIndex:0],subject];
            }else{
                recipients =[NSString stringWithFormat:@"mailto:?subject=%@",subject];
            }
            
            NSString *_body = [NSString stringWithFormat:@"&body=%@",body];
            
            NSString *email = [NSString stringWithFormat:@"%@%@", recipients, _body];
            email = [email stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:email]];
        }
    }
}

-(void)sendMessageWithBody:(NSString*)body recepients:(NSArray*)recepients presentingController:(id)controller{
    
    Class messageClass = (NSClassFromString(@"MFMessageComposeViewController"));
    
    if ([messageClass canSendText]) {
        [self displayMessageComposerWithMEssage:body andRecepients:recepients presentingController:controller];
    }

}

-(void) displayMailComposerSheetWithSubject:(NSString*)subject andBody:(NSString*)body recepients:(NSArray*)recepients  {
    MFMailComposeViewController *picker = [[MFMailComposeViewController alloc] init];
    picker.mailComposeDelegate = self;
    if (_SYSTEM_VERSION_GREATER_THAN_7) {
         picker.navigationBar.tintColor = [UIColor whiteColor];
    }
    [picker setSubject:subject];
    
    // Set up recipients
    [picker setToRecipients:recepients];
    [picker setMessageBody:body isHTML:NO];
    
    [[[APPDELEGATE window] rootViewController] presentViewController:picker animated:YES
                                                          completion:^{
                                                              
                                                          }];
}


-(void)displayMessageComposerWithMEssage:(NSString*)message andRecepients:(NSArray*)recepients presentingController:(id)controller{
    
    MFMessageComposeViewController *messageVC = [[MFMessageComposeViewController alloc] init];
    [messageVC setBody:message];
    [messageVC setRecipients:recepients];
    [messageVC setMessageComposeDelegate:self];
    if (_SYSTEM_VERSION_GREATER_THAN_7) {
        messageVC.navigationBar.tintColor = [UIColor whiteColor];
    }

    [controller presentViewController:messageVC animated:YES
                                                          completion:^{
                                                              
                                                          }];
    
}

#pragma mark - Mail Composer delegates

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
    // Notifies users about errors associated with the interface
    switch (result)
    {
        case MFMailComposeResultCancelled:
            break;
        case MFMailComposeResultSaved:
            break;
        case MFMailComposeResultSent:
            break;
        case MFMailComposeResultFailed:
            break;
        default:
            break;
    }
    
    [controller dismissViewControllerAnimated:YES completion:^{
        
    }];
}


#pragma mark - Message Composer delegates
- (void)messageComposeViewController:(MFMessageComposeViewController *)controller didFinishWithResult:(MessageComposeResult)result{
    
    switch (result) {
        case MessageComposeResultCancelled:
        case MessageComposeResultSent:
            break;
            
        default:
            break;
    }
    
    [controller dismissViewControllerAnimated:YES completion:^{
        [[NSNotificationCenter defaultCenter]postNotificationName:kNotif_ComposerDismissed object:nil];
    }];
}

-(void)postOnTwitter:(NSString*)message andImage:(UIImage *)image{
    
    SLComposeViewController *tweetSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeTwitter];
    [tweetSheet setInitialText:message];
    [tweetSheet addImage:image];

    [[[APPDELEGATE window] rootViewController] presentViewController:tweetSheet animated:YES completion:nil];
    
    
}

-(void)postOnFacebook:(NSString*)message andImage:(UIImage *)image{
    
    SLComposeViewController *tweetSheet = [SLComposeViewController composeViewControllerForServiceType:SLServiceTypeFacebook];
    [tweetSheet setInitialText:message];
    [tweetSheet addImage:image];
    [[[APPDELEGATE window] rootViewController] presentViewController:tweetSheet animated:YES completion:nil];
}


@end
