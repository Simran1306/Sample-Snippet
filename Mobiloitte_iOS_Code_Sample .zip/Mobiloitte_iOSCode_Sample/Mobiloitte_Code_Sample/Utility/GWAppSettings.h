//
//  GWAppSettings.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface GWAppSettings : NSObject

@property (strong, readwrite) UIColor *app_blueColor;
@property (strong, readwrite) UIColor *app_greenColor;
@property (strong, readwrite) UIColor *app_redColor;
@property (strong, readwrite) UIColor *app_lightGreyColor;
@property (strong, readwrite) UIColor *app_darkGreyColor;


-(UIFont*)app_HelveticaRegularWithSize:(CGFloat)size;
-(UIFont*)app_HelveticaThinWithSize:(CGFloat)size;
-(UIFont*)app_HelveticaBoldWithSize:(CGFloat)size;
-(UIFont*)app_HelveticaNeueMediumWithSize:(CGFloat)size;

+ (GWAppSettings *)sharedInstance;

@end
