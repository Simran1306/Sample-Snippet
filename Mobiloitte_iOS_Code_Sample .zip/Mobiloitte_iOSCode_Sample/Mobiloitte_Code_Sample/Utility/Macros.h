//
//  Macros.h
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#ifndef Demo_Macros_h
#define Demo_Macros_h

#endif


// Service Base URLs
//Local
//#define kBaseURL                    @""

//Staging
//#define kBaseURL                    @""

//Live URL
#define kBaseURL                    @""


#warning edit below
#define kDEBUG                       1  // 0= email validation of @unlv.nevada.edu
                                        // 1= no email validation

/***
 ***    APP constatnts
 ***/


/*****
 **** Notification names
 ****/
#define k_Notification_Recieved     @"newNotificationRecievedf"

#define kUserFirstTimeRegistered    @"checkIfUserRecentlyRegistered"

#define kUser_AndroidAppAlert       @"checkIfAndroidalertisshown"

#define kNotif_SubmitButtonTapped   @"submitButtonTapped"

#define kNotif_EventDeleted         @"EVENT_DELETED"

#define kNotif_UpdateEventDetail    @"UPDATE_DETAIL"

#define kNotif_ComposerDismissed    @"COMPOSER_DISMISSED"

#define kNotif_ReloadFriendScreen   @"RELOAD_FG"

#define kNotif_ShouldUpdateHome     @"UPDATE_HOME"

#define kNotif_UpdateHomeAfterDelete    @"EVENT_DELETED_UPDATE"

#define kNotif_UpdateProfile        @"UPDATE_PROFILE"

/*****
 **** Static messages
 ****/
#define kNetworkErrorMessage        @"Your internet connection appears to be offline. Please check your internet connection and try again."
#define k500Msg                     @"Sorry, We are currently experiencing some technical difficulties. Please email at support@Demoapp.com"
#define kAccessDeniedMsg            @"In order to find friends and family already on Demo!, please allow Demo! to have access to your contacts.\n\nYou can do this by going to Settings > Privacy > Contacts and turning Demo! ON"

#define kNoData_search              @"Sorry, No results were found matching your query."
#define kNoData_friends             @"Hmmm... Seems like you haven't added any friends yet."
#define kNoData_friendsEvent        @"Seems like you haven't added any friends yet. Add some friends and try again."
#define kNoData_group               @"Seems like you haven't created any groups yet."
#define kNoData_contacts            @"Sorry..No Contacts were found on your device."
#define kNoData_home                @"Hmmm... Seems like nothing much is going on right now. Why not create your own event and invite everyone?\n\nIt's pretty simple, just tap on the \"+\" button below and create a new event."
#define kNoData_profile_tag         @"No one has tagged you in any photos yet"
#define kNoData_profile_attend      @"You haven't attended any events yet"
#define kHomeAlertMsg1              @"Tell your friends that Demo! is available for Android phones now too!"
#define kHomeAlestMsg2              @"Use the two tabs, \"UNLV\" and \"Friends\" on the bottom of the homepage to switch from seeing events posted for all of UNLV or just events posted by your friends"



/*****
 **** Commonly used methods
 ****/

#define kDef                        [NSUserDefaults standardUserDefaults]
#define APPDELEGATE                 (GWAppDelegate*)[[UIApplication sharedApplication]delegate]
#define _SYSTEM_VERSION_GREATER_THAN_7 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)





/*****
 **** Importing Classes
 ****/
// Importing Frameworks
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <MessageUI/MessageUI.h>
#import <MapKit/MapKit.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import <Social/Social.h>
#import <AddressBook/AddressBook.h>
#import <CoreLocation/CoreLocation.h>
#import <AudioToolbox/AudioToolbox.h>
// Importing google analytic classes

#import "GAI.h"

// Custom UI Components
#import "SIAlertView.h"
#import "SIActionSheet.h"
#import "GWTextField.h"
#import "GWSolidButton.h"           // 
#import "GWImageButton.h"           // 
#import "JASidePanelController.h"  // reveal slider (reference facebook app)
#import "UIViewController+JASidePanel.h"
#import "REMenu.h"                  // used from animated drop down (reference vine app)
#import "iCarousel.h"               // used for photo carousel
#import "GWMenu.h"                  // used for bubble view animation (reference path app)
#import "GWFormSheetController.h"   // used for displaying formsheet style modal on iphone
#import "GWChat.h"                  // for showing chat keyboard

// Importing utility classes
#import "GWUtility.h"
#import "GWRoundedImageView.h"
#import "GWAppSettings.h"
#import "GWDateFormatter.h"
#import "MBProgressHUD.h"
#import "GWComposer.h"
#import "GWTextView.h"
#import "GWImagePickerController.h"
#import "AFNetworking.h"
#import "GWBarButton.h"
#import "GWAnnotation.h"
#import "NSDictionary+NullChecker.h"
#import "CBAutoScrollLabel.h"
#import "GLTapLabel.h"
#import "GGFullscreenImageViewController.h"

// Importing API Manager classes
#import "GWHTTPClient.h"
#import "GWServiceHelper.h"

// Importing model classes
#import "GWBaseObj.h"
#import "GWEventObj.h"
#import "GWPhotoObj.h"
#import "GWCommentObj.h"
#import "GWUserObj.h"
#import "GWFriendObj.h"
#import "GWGroupObj.h"
#import "GWPagination.h"
#import "GWNotificationObj.h"

// Importing View Controllers
#import "GWAppDelegate.h"
#import "GWNavigationController.h"

    // sign up section
#import "GWSignUpVC.h"
#import "GWCompleteProfileVC.h"
#import "GWForgotPasswordVC.h"

    // home section
#import "GWRearCell.h"
#import "GWNotificationCell.h"
#import "GWRearViewController.h"
#import "GWEventCommentCell.h"
#import "GWEventDetailCell.h"
#import "GWEventImageCell.h"
#import "GWHomeVC.h"

    // importing photo detail screen
#import "GWPhotoDetailVC.h"

    // importing create event section
#import "GWTimeCell.h"
#import "GWCategoryCell.h"
#import "GWFriendGroupCell.h"
#import "GWGroupCell.h"
#import "GWCreateGroupVC.h"
#import "GWFriendGroupVC.h"
#import "GWCreateEventVC.h"
#import "GWGroupDetailVC.h"

    // Find Friends Section
#import "GWFindCell.h"
#import "GWFindFriendListVC.h"
#import "GWPhoneVC.h"

    // Settings section
#import "GWCommonTextVC.h"
#import "GWSettingsVC.h"

    //Importing comment section
#import "GWCommentCell.h"
#import "GWCommentVC.h"


    // Importing Profile screens
#import "GWUserCell.h"
#import "GWUserUpcomingCell.h"
#import "GWUserPrfoileVC.h"


    // Importing My Profile Screen
#import "GWEnterBioVC.h"
#import "GWMyProfileCell.h"
#import "GWMyProfileVC.h"

    // Importing upcoming events section
#import "GWUpcomingCell.h"
#import "GWUpcomingEventVC.h"

    // Importing Event Detail Screen
#import "GWEventDetailFirstCell.h"
#import "GWEventDetailVC.h"


    // Importing Friend screens
#import "GWFriendCell.h"
#import "GWCommonFriendListVC.h"

    // Importing Map screens
#import "GWMapVC.h"


    // Importing search result screen
#import "GWSearchResultVC.h"



