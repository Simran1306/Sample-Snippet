//
//  NSDictionary+NullChecker.m
//  Demo!
//
//  Created by Apoorve Tyagi on 10/30/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "NSDictionary+NullChecker.h"

@implementation NSDictionary (NullChecker)

-(id)objectForKeyNotNull:(id)key expectedObj:(id)obj{
    id object = [self objectForKey:key];

    if (object == nil){
        return obj;
    }
    
   	if (object == [NSNull null])
		return obj;
	return object;

}



@end
