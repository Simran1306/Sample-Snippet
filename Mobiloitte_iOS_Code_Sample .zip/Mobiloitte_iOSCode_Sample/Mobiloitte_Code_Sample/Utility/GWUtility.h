//
//  GWUtility.h
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"
#include <CommonCrypto/CommonDigest.h>

typedef void(^alertAction)(int tag, SIAlertViewButtonType type, BOOL subtitleSelected);
typedef void(^actionSheetAction)(int tag, SIActionSheetButtonType type);

@interface GWUtility : NSObject


// C Functions
void setleftBarButton (id controller, NSString* imageName);

void setRightBarButton (id controller, NSString* imageName);

void removeRightBarButtonItem(id controller);

void removeLeftBarButtonItem(id controller);

void setRightBarButtonForHome (id controller, NSString* imageName);

void setRevealBarButton (id controller, NSString* count);

void setNavigationTitle (id controller, NSString* imageName, NSString *title);

bool isValidEmail(NSString *checkString);

NSDate* convertToDate(NSString* dateString, NSString* format);

NSString* convertToString(NSDate* date, NSString* format);

NSString* trimSpace(NSString* str);

UIImage* imageFromColor(UIColor* color);

NSURL* getPhotoURL(NSString* urlString);

NSMutableArray* getAllContactsFromDevice();

NSString* hashedString(NSString* str);







// static methods
+(void) displayReachabilityAlert;

+(void) showaActionSheetWithTitle:(NSString *)title andMessage:(NSString *)message andButtonAction:(actionSheetAction)action andCancelButton:(NSString *)cancelButton andOtherButtons:(NSString *)otheButtons,...NS_REQUIRES_NIL_TERMINATION;

+(void) showaAlertWithTitle:(NSString *)title andMessage:(NSString *)message andSubtitle:(NSString *)subtitle andButtonAction:(alertAction)action andCancelButton:(NSString *)cancelButton andOtherButtons:(NSString *)otheButton;

BOOL isFourInchDisplay();

@end
