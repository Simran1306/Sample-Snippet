//
//  GWImagePickerController.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWImagePickerController.h"
static GWImagePickerController *pickerSharedInstance;

@interface GWImagePickerController()
@property (nonatomic, copy) pickerCompletionBlock completionBlock;

@end

@implementation GWImagePickerController

+(GWImagePickerController *)sharedManager {
    
    static dispatch_once_t pred;
    
    dispatch_once(&pred, ^{
        pickerSharedInstance = [[GWImagePickerController alloc] init];
    });
    
    return pickerSharedInstance;
}

-(void)openCameraWithSelectedImage:(pickerCompletionBlock)block fromController:(id)controller{
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera]){
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        [imagePicker setDelegate:self];
        [imagePicker setSourceType:UIImagePickerControllerSourceTypeCamera];
        [imagePicker setMediaTypes:[NSArray arrayWithObject:(NSString*)kUTTypeImage]];
        [imagePicker setAllowsEditing:YES];
        [controller presentViewController:imagePicker animated:YES completion:nil];
    }
    
    self.completionBlock = block;
}

-(void)openPhotoLibraryWithSelectedImage:(pickerCompletionBlock)block fromController:(id)controller{
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary]){
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        [imagePicker setDelegate:self];
        [imagePicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
        [imagePicker setMediaTypes:[NSArray arrayWithObject:(NSString*)kUTTypeImage]];
        [imagePicker setAllowsEditing:YES];
        if (_SYSTEM_VERSION_GREATER_THAN_7) {
            imagePicker.navigationBar.tintColor = [UIColor whiteColor];
        }
        [controller presentViewController:imagePicker animated:YES completion:nil];
    }
    self.completionBlock = block;
}


#pragma mark - UIImagepickerController Delegate methods
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    UIImage *sahreImage=[info objectForKey:UIImagePickerControllerEditedImage];
    self.completionBlock(sahreImage);
   
    [picker dismissViewControllerAnimated:YES completion:nil];

}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

@end
