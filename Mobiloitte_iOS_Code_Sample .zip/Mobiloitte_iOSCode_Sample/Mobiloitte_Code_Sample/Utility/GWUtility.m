//
//  GWUtility.m
//  Demo
//
//  Created by Apoorve Tyagi on 8/8/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWUtility.h"
#import "GWDateFormatter.h"
#import "GWBarButton.h"
@implementation GWUtility

/**
 ** Sets a left bar button item to the passed 'controller' using the specified 'image name'
 **/
void setleftBarButton (id controller, NSString* imageName){
    UIViewController *VC = (UIViewController *)controller;
    UIImage *image = [UIImage imageNamed:imageName];
    
    GWBarButton *leftButton = [GWBarButton buttonWithType:UIButtonTypeCustom];
    [leftButton setIsLeft:YES];
    [leftButton setFrame:CGRectMake(0, 0, MAX(image.size.width, 40),image.size.height)];
    [leftButton setImage:image forState:UIControlStateNormal];
    [leftButton addTarget:VC action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButton = [[UIBarButtonItem alloc] initWithCustomView:leftButton];
    [VC.navigationItem setLeftBarButtonItem:leftBarButton];
    
    leftBarButton = nil;
    leftButton = nil;
}

/**
 ** Sets a right bar button item to the passed 'controller' using the specified 'image name'
 **/
void setRightBarButton (id controller, NSString* imageName){
    UIViewController *VC = (UIViewController *)controller;
    UIImage *image = [UIImage imageNamed:imageName];
    
    GWBarButton *rightButton = [GWBarButton buttonWithType:UIButtonTypeCustom];
    [rightButton setImage:image forState:UIControlStateNormal];
    [rightButton setIsLeft:NO];
    [rightButton setFrame:CGRectMake(0, 0, MAX(image.size.width, 40),MAX(image.size.height, 40))];
    [rightButton.titleLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:12.0]];
    [rightButton setTitleShadowColor:[UIColor blackColor] forState:UIControlStateNormal];
    [rightButton addTarget:VC action:@selector(rightButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    [VC.navigationItem setRightBarButtonItem:rightBarButton];
    
    rightBarButton = nil;
    rightButton = nil;
}

void removeRightBarButtonItem(id controller){
    UIViewController *VC = (UIViewController *)controller;
    [VC.navigationItem setRightBarButtonItem:nil];
}


void removeLeftBarButtonItem(id controller){
    UIViewController *VC = (UIViewController *)controller;
    [VC.navigationItem setLeftBarButtonItem:nil];
}

/**
 ** Sets a right bar button item to the passed 'controller'(basically home) using the specified 'image name'
 ** A drop down image is added to the same
 **/
void setRightBarButtonForHome (id controller, NSString* imageName){
    UIViewController *VC = (UIViewController *)controller;
    UIImage *image = [UIImage imageNamed:imageName];
    
    GWBarButton *rightButton = [GWBarButton buttonWithType:UIButtonTypeCustom];
    [rightButton setIsLeft:NO];
    [rightButton setImage:image forState:UIControlStateNormal];
    [rightButton setBackgroundImage:[UIImage imageNamed:@"down_arrow.png"] forState:UIControlStateNormal];
    [rightButton setFrame:CGRectMake(0, 0, 57,30)];
    [rightButton.titleLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:12.0]];
    [rightButton setTitleShadowColor:[UIColor blackColor] forState:UIControlStateNormal];
    [rightButton setImageEdgeInsets:UIEdgeInsetsMake(0, -20, 0, 0)];
    [rightButton addTarget:VC action:@selector(rightButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *rightBarButton = [[UIBarButtonItem alloc] initWithCustomView:rightButton];
    [VC.navigationItem setRightBarButtonItem:rightBarButton];
    
    rightBarButton = nil;
    rightButton = nil;
}

/**
 ** Sets a left reveal bar button item to the passed 'controller' with notification count shown as a badge
 **/
void setRevealBarButton (id controller, NSString* count){
    UIViewController *VC = (UIViewController *)controller;
    UIImage *image = [UIImage imageNamed:([count integerValue]>0)?@"reveal-icon-notif.png":@"reveal-icon.png"];
    
    UIButton *reveal = [UIButton buttonWithType:UIButtonTypeCustom];
    [reveal setImage:image forState:UIControlStateNormal];
    if ([count integerValue]>0) {
        [reveal setTitle:count forState:UIControlStateNormal];
    }else{
        [reveal setTitle:@"" forState:UIControlStateNormal];

    }

    [reveal setFrame:CGRectMake(0, 0, MAX(image.size.width, 60),44)];
    [reveal.titleLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:12.0]];
    [reveal setTitleShadowColor:[UIColor blackColor] forState:UIControlStateNormal];
    [reveal setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [reveal.titleLabel setShadowOffset:CGSizeMake(0.0, 1.0)];
    
    if (_SYSTEM_VERSION_GREATER_THAN_7) {
        [reveal setTitleEdgeInsets:UIEdgeInsetsMake(-20.0, -50.0, 0.0, 0.0)];
        [reveal setImageEdgeInsets:UIEdgeInsetsMake(-8.0, -15.0, 0.0, 0.0)];
    }else{
        [reveal setTitleEdgeInsets:UIEdgeInsetsMake(-20.0, -23.0, 0.0, 0.0)];
        [reveal setImageEdgeInsets:UIEdgeInsetsMake(-8.0, 5.0, 0.0, 0.0)];
    }

    [reveal addTarget:VC action:@selector(leftButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [reveal addTarget:VC.sidePanelController action:@selector(showLeftPanelAnimated:) forControlEvents:UIControlEventTouchUpInside];

    UIBarButtonItem *revealBarButton = [[UIBarButtonItem alloc] initWithCustomView:reveal];
    [VC.navigationItem setLeftBarButtonItem:revealBarButton];
    
    revealBarButton = nil;
    reveal = nil;
}

/**
 ** Sets navigation title to the passed 'controller' , title view could either be an 'image' or a string 'title'
 **/
void setNavigationTitle (id controller, NSString* imageName, NSString *title){
    UIViewController *VC = (UIViewController *)controller;
    if (imageName) {
        UIView *titleView = [[UIView alloc] initWithFrame:CGRectZero];

        UIImage *image = [UIImage imageNamed:imageName];
        UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
        [button setFrame:CGRectMake(0, 0, image.size.width, image.size.height)];
        [button setImage:image forState:UIControlStateNormal];
        [button setImage:image forState:UIControlStateHighlighted];

        CGRect frame;
        frame = titleView.frame;
        frame.size.height = 44.0;
        frame.size.width = button.frame.size.width;
        titleView.frame = frame;
        titleView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;
        titleView.autoresizesSubviews = YES;
        [titleView addSubview:button];
        
        [button setCenter:titleView.center];
        [button addTarget:VC action:@selector(headerImageTapepd:) forControlEvents:UIControlEventTouchUpInside];
        [VC.navigationItem setTitleView:titleView];
    }
    
    else{
        CGSize size = [title sizeWithFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:20.0] constrainedToSize:CGSizeMake(CGFLOAT_MAX, 44) lineBreakMode:NSLineBreakByWordWrapping];
        CBAutoScrollLabel*leftLabel =   [[CBAutoScrollLabel alloc] initWithFrame:CGRectMake(0, 0, ((size.width>170)?170:size.width+5), 44)];
        [leftLabel setScrollDirection:CBAutoScrollDirectionLeft];
        [leftLabel setLabelSpacing:20.0];
        [leftLabel observeApplicationNotifications];
        [leftLabel setFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:20.0]];
        [leftLabel setTextColor:[UIColor whiteColor]];
        [leftLabel setShadowColor:[UIColor blackColor]];
        [leftLabel setShadowOffset:CGSizeMake(0.0, 1.0)];
        leftLabel.textAlignment = NSTextAlignmentCenter;
        [leftLabel setText:title];
        [leftLabel setCenter:CGPointMake(VC.view.center.x, leftLabel.center.y)];
        [VC.navigationItem setTitleView:leftLabel];
    }
}


/*
 * Function to check email validation
 */
bool isValidEmail(NSString *checkString)
{
    if (kDEBUG) {
        NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
        return [emailTest evaluateWithObject:checkString];
    }else{
        if ([[checkString lowercaseString] hasSuffix:@"@unlv.nevada.edu"]) {
            return YES;
        }
        return NO;
    }
}

/**
 ** Function converts the passed 'dateString' to NSDate. 'format' is the date format in which the dateString is in
 **/
NSDate* convertToDate(NSString* dateString, NSString* format){
    GWDateFormatter *dateFormatter = [GWDateFormatter sharedManager];
    [dateFormatter setDateFormat:format];
    return [dateFormatter dateFromString:dateString];
}

/**
 ** Function converts the passed NSDate to dateString in the specified date format
 **/
NSString* convertToString(NSDate* date, NSString* format){
    GWDateFormatter *dateFormatter = [GWDateFormatter sharedManager];
    [dateFormatter setDateFormat:format];
    return [dateFormatter stringFromDate:date];
}

NSURL* getPhotoURL(NSString* urlString){
    return [NSURL URLWithString:urlString relativeToURL:nil];
}


/**
 ** A Static method for displaying network connection error
 **/
+(void) displayReachabilityAlert{
    
    [GWUtility showaAlertWithTitle:@"Network Connection Error!" andMessage:@"Your internet connection appears to be offline.Please check your internet connection and try again." andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
        
    } andCancelButton:nil andOtherButtons:@"OK"];
}

/**
 ** A Static method for displaying custom actionsheet
 ** 'title' is the the title for the alert
 ** 'message' is the alert's message
 ** 'action' a block invoked when any button is tapped, which gives the buttons tag and button type
 ** 'cancelButton' is the title for cancel button, displayed in red color
 ** 'otherButton' are title for other button
 **/
+(void) showaActionSheetWithTitle:(NSString *)title andMessage:(NSString *)message andButtonAction:(actionSheetAction)action andCancelButton:(NSString *)cancelButton andOtherButtons:(NSString *)otheButtons,...NS_REQUIRES_NIL_TERMINATION
{

    SIActionSheet *alertView = [[SIActionSheet alloc] initWithTitle:title andMessage:message];
    int i = 1;
    
    if (otheButtons) {
        va_list args;
        va_start(args, otheButtons);
        for (NSString *arg = otheButtons; arg != nil; arg = va_arg(args, NSString*)) {
            [alertView addButtonWithTitle:arg
                                     type:SIActionSheetButtonTypeDefault
                                      tag:i
                                  handler:^(SIActionSheet *alertView) {
                                      action(i,SIActionSheetButtonTypeDefault);

            }];
            i++;
        }
        va_end(args);
    }
    
    if (cancelButton) {
        [alertView addButtonWithTitle:cancelButton
                                 type:SIActionSheetButtonTypeCancel
                                  tag:i
                              handler:^(SIActionSheet *alertView) {
                                  action(0,SIActionSheetButtonTypeCancel);
                              }];
        i++;
    }

    alertView.transitionStyle = SIAlertViewTransitionStyleSlideFromBottom;
    alertView.backgroundStyle = SIAlertViewBackgroundStyleSolid;
    
    [alertView show];
    
}


/**
 ** A Static method for displaying custom alert
 ** 'title' is the the title for the alert
 ** 'message' is the alert's message
 ** 'subtitle' only used for RSVP alert to show check mark on bottom of alert
 ** 'action' a block invoked when any button is tapped, which gives the buttons tag and button type
 ** 'cancelButton' is the title for cancel button, displayed in red color
 ** 'otherButton' are title for other button
 **/

+(void) showaAlertWithTitle:(NSString *)title andMessage:(NSString *)message andSubtitle:(NSString *)subtitle andButtonAction:(alertAction)action andCancelButton:(NSString *)cancelButton andOtherButtons:(NSString *)otheButton{
    SIAlertView *alertView = [[SIAlertView alloc] initWithTitle:title andMessage:message andSubtitle:subtitle];
    int i = 0;
    
    if (cancelButton) {
        [alertView addButtonWithTitle:cancelButton
                                 type:SIAlertViewButtonTypeCancel
                                  tag:i
                              handler:^(SIAlertView *alertView) {
                                  UIButton *but = (UIButton *)[alertView.containerView viewWithTag:21012];
                                  action(i,SIAlertViewButtonTypeCancel,[but isSelected]);
                              }];
        i++;
    }
    
    if (otheButton) {
        [alertView addButtonWithTitle:otheButton
                                 type:SIAlertViewButtonTypeDefault
                                  tag:i
                              handler:^(SIAlertView *alertView) {
                                  UIButton *but = (UIButton *)[alertView.containerView viewWithTag:21012];
                                  action(i,SIAlertViewButtonTypeDefault,[but isSelected]);
                                  
                              }];
    }
    
   
    
    alertView.transitionStyle = SIAlertViewTransitionStyleBounce;
    alertView.backgroundStyle = SIAlertViewBackgroundStyleSolid;
     
    [alertView show];

}

/**
 ** A function that trims the leading whitespaces in the passed string
 **/
NSString* trimSpace(NSString* str){
    return [str stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
}

/**
 ** A function an UIImage object of passed UIColor
 **/
UIImage* imageFromColor(UIColor* color){
    
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context,[color CGColor]);
    
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}


/**
 ** A function that trims the leading whitespaces in the passed string, adds round corner to the specifed side
 **/
UIImage* imageFromColorWithRoundingRect(UIColor* color, BOOL isLeft, CGFloat cornerRadius){
    
    CGRect r = CGRectMake(0, 0, 5, 5);

    UIGraphicsBeginImageContext(r.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context,[color CGColor]);

    CGContextFillRect(context, r);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return img;
}

NSMutableArray * getAllContactsFromDevice() {
    
//    float version = [[[UIDevice currentDevice] systemVersion] floatValue];
//    if (version < 6.0) {
//        ABAddressBookRef addressBook = ABAddressBookCreate();
//        NSArray *contactList = (__bridge NSArray *)ABAddressBookCopyArrayOfAllPeople(addressBook);
//        addressBook = nil;
//        return contactList;
//    }
    
    CFErrorRef error;
    ABAddressBookRef addressBook = ABAddressBookCreateWithOptions(NULL, &error);
    
    __block BOOL accessGranted = NO;
    
    if (ABAddressBookRequestAccessWithCompletion != NULL) { // we're on iOS 6
        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        
        ABAddressBookRequestAccessWithCompletion(addressBook, ^(bool granted, CFErrorRef error) {
            accessGranted = granted;
            dispatch_semaphore_signal(sema);
        });
        
        dispatch_semaphore_wait(sema, DISPATCH_TIME_FOREVER);
    }
    else { // we're on iOS 5 or older
        accessGranted = YES;
    }
    
    NSArray *thePeople = nil;
    if (accessGranted) {
        thePeople = (__bridge NSArray *)ABAddressBookCopyArrayOfAllPeople(addressBook);
    }
    
    NSMutableArray *contactsArray = [[NSMutableArray alloc] init];
    for (int i = 0; i < [thePeople count]; i++) {
        ABRecordRef recordRef = (__bridge ABRecordRef)[thePeople objectAtIndex:i];
        GWFriendObj *f_Info=[[GWFriendObj alloc] init];
        
        NSMutableString * firstName = (__bridge NSMutableString *)ABRecordCopyValue(recordRef, kABPersonFirstNameProperty);
        NSMutableString * lastName = (__bridge NSMutableString *)ABRecordCopyValue(recordRef, kABPersonLastNameProperty);
        
        NSString *fname = ([firstName length] > 0) ? [firstName capitalizedString] : @"";
        NSString *lname = ([lastName length] > 0) ? [lastName capitalizedString] : @"";

        [f_Info setUserName:[NSString stringWithFormat:@"%@ %@",fname,lname]];
        
        CFTypeRef phoneProperty = ABRecordCopyValue((ABRecordRef)recordRef, kABPersonPhoneProperty);
        NSArray *phones = (__bridge NSArray *)ABMultiValueCopyArrayOfAllValues(phoneProperty);
        NSString *phoneNumberString = [phones componentsJoinedByString:@","];
        NSCharacterSet *doNotWant = [NSCharacterSet characterSetWithCharactersInString:@"-() "];
        
        [f_Info setUserPhoneNo:[[phoneNumberString componentsSeparatedByCharactersInSet: doNotWant] componentsJoinedByString: @""]];
        
        if (f_Info.userPhoneNo && [[f_Info.userName stringByReplacingOccurrencesOfString:@" " withString:@""] length]) {
            if (!f_Info.userName.length) {
                [f_Info setUserPhoneNo:[[f_Info.userPhoneNo componentsSeparatedByString:@","] objectAtIndex:0]];
            }
            [contactsArray addObject:f_Info];
        }
    }
    
    return contactsArray;
}

BOOL isFourInchDisplay() {
    return ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone && [UIScreen mainScreen].bounds.size.height >= 500.0);
}


NSString* hashedString (NSString* inputText) {
    const char *cstr = [inputText cStringUsingEncoding:NSUTF8StringEncoding];
    NSData *data = [NSData dataWithBytes:cstr length:inputText.length];
    
    uint8_t digest[CC_SHA1_DIGEST_LENGTH];
    
    CC_SHA1(data.bytes, data.length, digest);
    
    NSMutableString* output = [NSMutableString stringWithCapacity:CC_SHA1_DIGEST_LENGTH * 2];
    
    for(int i = 0; i < CC_SHA1_DIGEST_LENGTH; i++) {
        [output appendFormat:@"%02x", digest[i]];
    }
    return output;
}

@end
