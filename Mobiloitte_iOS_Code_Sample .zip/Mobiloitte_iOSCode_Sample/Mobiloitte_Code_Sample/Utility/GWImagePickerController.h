//
//  GWImagePickerController.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

typedef void(^pickerCompletionBlock)(UIImage* image);

@interface GWImagePickerController : NSObject<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

+(GWImagePickerController *)sharedManager;

-(void)openCameraWithSelectedImage:(pickerCompletionBlock)block fromController:(id)controller;

-(void)openPhotoLibraryWithSelectedImage:(pickerCompletionBlock)block fromController:(id)controller;


@end
