//
//  GWComposer.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/21/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWComposer : NSObject<MFMailComposeViewControllerDelegate,MFMessageComposeViewControllerDelegate>

+(GWComposer *)sharedManager;

-(void)sendMailWithSubject:(NSString*)subject andBody:(NSString*)body recepients:(NSArray*)recepients;

-(void)sendMessageWithBody:(NSString*)body recepients:(NSArray*)recepients presentingController:(id)controller;

-(void)postOnTwitter:(NSString*)message andImage:(UIImage*)image;

-(void)postOnFacebook:(NSString*)message andImage:(UIImage*)image;


@end
