//
//  GWHTTPClient.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWHTTPClient.h"
static GWHTTPClient *_sharedClient;

@implementation GWHTTPClient

+ (GWHTTPClient *) sharedClient {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedClient = [[GWHTTPClient alloc] initWithBaseURL:[NSURL URLWithString:kBaseURL]];
    });
    
    return _sharedClient;
}

-(id) initWithBaseURL:(NSURL *)url {
    self = [super initWithBaseURL:url];
    self.parameterEncoding = AFJSONParameterEncoding;
    [self registerHTTPOperationClass:[AFJSONRequestOperation class]];
    if (!self) {
        return nil;
    }
    return self;
}


@end
