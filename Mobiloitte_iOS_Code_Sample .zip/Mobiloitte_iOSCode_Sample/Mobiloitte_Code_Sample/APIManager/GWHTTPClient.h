//
//  GWHTTPClient.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWHTTPClient : AFHTTPClient

+ (GWHTTPClient *)sharedClient;


@end
