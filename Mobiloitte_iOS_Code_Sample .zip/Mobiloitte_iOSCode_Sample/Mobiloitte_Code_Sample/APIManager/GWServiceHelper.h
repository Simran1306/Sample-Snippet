//
//  GWServiceHelper.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

typedef  enum _GWServiceMethod {
    
    GWService_signUp,
    GWService_completeProfile,
    GWService_login,
    GWService_forgotPassword,
    GWService_logOut
 
} GWServiceMethod;

@protocol GWServiceHelperDelegate <NSObject>

@optional

-(void)serviceResponse:(id)response andMethodName:(GWServiceMethod)methodName;
-(void)connectionFailWithError:(NSString*)error andMethodName:(GWServiceMethod)methodName;


@end


@interface GWServiceHelper : NSObject<NSURLConnectionDelegate>

@property (nonatomic, strong) NSURLConnection *connection;
@property (nonatomic, strong) NSMutableData *responseData;
@property (nonatomic, assign) id<GWServiceHelperDelegate> serviceHelperDelegate;

+ (GWServiceHelper *)sharedHelper;

-(void)callPOSTMethodWithData:(NSDictionary*)dict andMethodName:(GWServiceMethod)methodName;

-(void)callPUTMethodWithData:(NSDictionary*)dict andResourceID:(NSString*)resourceID andMethodName:(GWServiceMethod)methodName;


- (void)cancelAllRequests;

- (void)cancelGetTypeRequests;

- (void)cancelRequestwithName:(GWServiceMethod)methodName;


@end
