//
//  GWServiceHelper.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/12/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWServiceHelper.h"
static GWServiceHelper *_sharedHelper;

@interface GWServiceHelper(){
}
@end

@implementation GWServiceHelper

- (id)init{
    
    self = [super init];
    if (self) {
        // Custom initialization
    }
    return self;
}

+ (GWServiceHelper *) sharedHelper {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedHelper = [[GWServiceHelper alloc] init];
    });
    
    return _sharedHelper;
}

- (void)cancelGetTypeRequests{
    for (int i = 11; i<= 23; i++) {
        [self cancelRequestwithName:i];
    }
}

- (void)cancelAllRequests{
    [[[GWHTTPClient sharedClient] operationQueue] cancelAllOperations];
}

- (void)cancelRequestwithName:(GWServiceMethod)methodName{
    NSString *requestURL = [NSString stringWithFormat:@"%@/%@",kBaseURL,[self getMethodName:methodName]];
    NSArray *operationArray = [[[GWHTTPClient sharedClient] operationQueue] operations];

    for (AFJSONRequestOperation *queueOperation in operationArray) {
        if ([[[[(AFHTTPRequestOperation *)queueOperation request] URL] absoluteString] isEqualToString:requestURL]) {
            [queueOperation cancel];
        }
    }
}

#pragma mark - Webservice Call methods

-(void)callPOSTMethodWithData:(NSDictionary*)dict andMethodName:(GWServiceMethod)methodName{
    if (![APPDELEGATE isReachable]) {
        if (!self.serviceHelperDelegate) {
            return ;
        }
        if ([self.serviceHelperDelegate respondsToSelector:@selector(connectionFailWithError:andMethodName:)]) {
            [self.serviceHelperDelegate connectionFailWithError:kNetworkErrorMessage andMethodName:methodName];
        }
        return;
    }
    NSURLRequest *request = [self getPOSTFromDict:dict andMethodName:methodName];
    [self callWebServiceWithRequest:request andMethodName:methodName];
}

-(void)callPUTMethodWithData:(NSDictionary*)dict andResourceID:(NSString*)resourceID andMethodName:(GWServiceMethod)methodName{
    if (![APPDELEGATE isReachable]) {
        if ([self.serviceHelperDelegate respondsToSelector:@selector(connectionFailWithError:andMethodName:)]) {
            [self.serviceHelperDelegate connectionFailWithError:kNetworkErrorMessage andMethodName:methodName ];
        }
        return;
    }
    NSURLRequest *request = [self getPUTFromDict:dict andResourceID:resourceID andMethodName:methodName];
    [self callWebServiceWithRequest:request andMethodName:methodName];
}


-(NSString*)getMethodName:(GWServiceMethod)methodName{

    switch (methodName) {
        case GWService_signUp:
            return @"signUpWithHash.json";
        
        case GWService_completeProfile:
            return @"completeProfile.json";
            
        case GWService_login:
            return @"loginWithHash.json";
            
        case GWService_forgotPassword:
            return @"forgotPassword.json";
            
        case GWService_logOut:
            return @"logout.json";
            
        default:
            return @"";
    }
}

-(void)callWebServiceWithRequest:(NSURLRequest*)request andMethodName:(GWServiceMethod)methodName{

   AFJSONRequestOperation* operation =[AFJSONRequestOperation JSONRequestOperationWithRequest:request success:^(NSURLRequest *request, NSHTTPURLResponse *response, id JSON) {

        if ([[JSON objectForKey:@"responseCode"] integerValue]>=200 && [[JSON objectForKey:@"responseCode"] integerValue]<=299){
            if (!self.serviceHelperDelegate) {
                return ;
            }
            if ([self.serviceHelperDelegate respondsToSelector:@selector(serviceResponse:andMethodName:)]) {
                [self.serviceHelperDelegate serviceResponse:JSON andMethodName:methodName];
            }
        }else{
            if (!self.serviceHelperDelegate) {
                return ;
            }
            if ([self.serviceHelperDelegate respondsToSelector:@selector(connectionFailWithError:andMethodName:)]) {
                [self.serviceHelperDelegate connectionFailWithError:[JSON objectForKey:@"responseMessage"] andMethodName:methodName];
            }
        }
        
    } failure:^(NSURLRequest *request, NSHTTPURLResponse *response, NSError *error, id JSON) {
        NSLog(@"error: %@",error);
        
        if ([error code] == NSURLErrorCancelled) {
            return ;
        }
        if (!self.serviceHelperDelegate) {
            return ;
        }
        if ([self.serviceHelperDelegate respondsToSelector:@selector(connectionFailWithError:andMethodName:)]) {
            [self.serviceHelperDelegate connectionFailWithError:k500Msg andMethodName:methodName];
        }

    }];
    
    [[[GWHTTPClient sharedClient]operationQueue] addOperation:operation];
}

#pragma mark - Request formation
/**
 ** Returns a POST request from the passed parameter dictionary
 **/
-(NSURLRequest*)getPOSTFromDict:(NSDictionary*)dict andMethodName:(GWServiceMethod)methodName{
    NSURLRequest *request = nil;
    
    if ([dict objectForKey:@"image"]){
        request = [self getMultipart:dict andHTTPMethod:@"POST" andPath:[self getMethodName:methodName] andMethodName:methodName];
    
    }else{
        request = [[GWHTTPClient sharedClient] requestWithMethod:@"POST" path:[self getMethodName:methodName] parameters:dict];
    }

    return request;
}

/**
 ** Returns a PUT request from the passed parameter dictionary
 **/
-(NSURLRequest*)getPUTFromDict:(NSDictionary*)dict andResourceID:(NSString*)resourceID andMethodName:(GWServiceMethod)methodName{
    NSURLRequest *request = nil;
    
    if ([dict objectForKey:@"image"]) {
        request = [self getMultipart:dict andHTTPMethod:@"PUT" andPath:[NSString stringWithFormat:@"%@/%@.json",[self getMethodName:methodName],resourceID] andMethodName:methodName];
        
    }else{
        request = [[GWHTTPClient sharedClient] requestWithMethod:@"PUT" path:[NSString stringWithFormat:@"%@/%@.json",[self getMethodName:methodName],resourceID] parameters:dict];
    }
    
    return request;
}


-(NSURLRequest*)getMultipart:(NSDictionary*)dict andHTTPMethod:(NSString*)httpMethod andPath:(NSString*)path andMethodName:(GWServiceMethod)methodName{
    NSURLRequest *request = nil;

    NSMutableDictionary *requestDict = [NSMutableDictionary dictionaryWithDictionary:dict];
    [requestDict removeObjectForKey:@"image"];
    
    NSData *data = UIImageJPEGRepresentation([dict objectForKey:@"image"], 0.4);
    
    request = [[GWHTTPClient sharedClient] multipartFormRequestWithMethod:httpMethod path:path parameters:requestDict constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:data name:@"image" fileName:@"sampl.png" mimeType:@"image/jpeg"];
    }];
    
    return request;
}


@end