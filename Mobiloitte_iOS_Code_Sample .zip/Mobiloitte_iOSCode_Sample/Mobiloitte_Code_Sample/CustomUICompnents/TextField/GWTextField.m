//
//  GWTextField.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWTextField.h"

@implementation GWTextField{
    
    UIColor *_backgroundColor;
    UIColor *_placeholderTextColor;
    UIFont *_font;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self appearance];
    }
    return self;
}
-(id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self appearance];
    }
    return self;
}

- (void)appearance {

    _placeholderTextColor = [UIColor colorWithWhite:0.8 alpha:0.8];
    _font = [UIFont fontWithName:@"Helvetica-Oblique" size:14.0];
}

- (void)drawPlaceholderInRect:(CGRect)rect {
    [_placeholderTextColor setFill];
    if (_SYSTEM_VERSION_GREATER_THAN_7) {
        NSMutableParagraphStyle *style = [[NSParagraphStyle defaultParagraphStyle] mutableCopy];
        [style setAlignment:NSTextAlignmentCenter];
        NSDictionary *attr = [NSDictionary dictionaryWithObjectsAndKeys:_placeholderTextColor,NSForegroundColorAttributeName,_font,NSFontAttributeName, nil];
        [[self placeholder] drawInRect:CGRectMake(rect.origin.x, (rect.size.height- _font.pointSize)/2-1, rect.size.width, _font.pointSize+5) withAttributes:attr];
    }else{
        [[self placeholder] drawInRect:rect withFont:_font];

    }
}

@end
