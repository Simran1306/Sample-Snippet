//
//  SIActionSheet.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/16/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWAppSettings.h"
extern NSString *const SIActionSheetWillShowNotification;
extern NSString *const SIActionSheetDidShowNotification;
extern NSString *const SIActionSheetWillDismissNotification;
extern NSString *const SIActionSheetDidDismissNotification;

typedef NS_ENUM(NSInteger, SIActionSheetButtonType) {
    SIActionSheetButtonTypeDefault = 0,
    SIActionSheetButtonTypeDestructive,
    SIActionSheetButtonTypeCancel
};

typedef NS_ENUM(NSInteger, SIActionSheetBackgroundStyle) {
    SIActionSheetBackgroundStyleGradient = 0,
    SIActionSheetBackgroundStyleSolid,
};

typedef NS_ENUM(NSInteger, SIActionSheetTransitionStyle) {
    SIActionSheetTransitionStyleSlideFromBottom = 0,
    SIActionSheetTransitionStyleSlideFromTop,
    SIActionSheetTransitionStyleFade,
    SIActionSheetTransitionStyleBounce,
    SIActionSheetTransitionStyleDropDown
};

@class SIActionSheet;
typedef void(^SIActionSheetHandler)(SIActionSheet *alertView);

@interface SIActionSheet : UIView

@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *message;

@property (nonatomic, assign) SIActionSheetTransitionStyle transitionStyle; // default is SIActionSheetTransitionStyleSlideFromBottom
@property (nonatomic, assign) SIActionSheetBackgroundStyle backgroundStyle; // default is SIActionSheetButtonTypeGradient

@property (nonatomic, copy) SIActionSheetHandler willShowHandler;
@property (nonatomic, copy) SIActionSheetHandler didShowHandler;
@property (nonatomic, copy) SIActionSheetHandler willDismissHandler;
@property (nonatomic, copy) SIActionSheetHandler didDismissHandler;

@property (nonatomic, readonly, getter = isVisible) BOOL visible;

@property (nonatomic, strong) UIColor *viewBackgroundColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIColor *titleColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIColor *messageColor NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIFont *titleFont NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIFont *messageFont NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, strong) UIFont *buttonFont NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR;
@property (nonatomic, assign) CGFloat cornerRadius NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR; // default is 2.0
@property (nonatomic, assign) CGFloat shadowRadius NS_AVAILABLE_IOS(5_0) UI_APPEARANCE_SELECTOR; // default is 8.0

- (id)initWithTitle:(NSString *)title andMessage:(NSString *)message;
- (void)addButtonWithTitle:(NSString *)title type:(SIActionSheetButtonType)type tag:(int)tag handler:(SIActionSheetHandler)handler;

- (void)show;
- (void)dismissAnimated:(BOOL)animated;

@end
