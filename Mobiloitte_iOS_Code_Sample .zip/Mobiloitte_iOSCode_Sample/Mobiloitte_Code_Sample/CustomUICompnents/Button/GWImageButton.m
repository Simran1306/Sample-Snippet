//
//  GWImageButton.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/23/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWImageButton.h"

@implementation GWImageButton

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self appearanceButton];
}

- (void)appearanceButton {
    
    UIImage *normalImage = [self imageForState:UIControlStateNormal];
    UIImage *hihlightedImage = [self imageForState:UIControlStateHighlighted];
    UIImage *selectedImage = [self imageForState:UIControlStateSelected];
    
    [self setImage:nil forState:UIControlStateNormal];
    [self setImage:nil forState:UIControlStateHighlighted];
    [self setImage:nil forState:UIControlStateSelected];

	CGFloat hInset = floorf(normalImage.size.width / 2);
	CGFloat vInset = floorf(normalImage.size.height / 2);
	UIEdgeInsets insets = UIEdgeInsetsMake(vInset, hInset, vInset, hInset);
    
	normalImage = [normalImage resizableImageWithCapInsets:insets];
	hihlightedImage = [[normalImage tintedImageUsingColor:[UIColor colorWithWhite:0.0 alpha:0.2]] resizableImageWithCapInsets:insets];
	selectedImage = [selectedImage resizableImageWithCapInsets:insets];

    
	[self setBackgroundImage:normalImage forState:UIControlStateNormal];
	[self setBackgroundImage:hihlightedImage forState:UIControlStateHighlighted];
	[self setBackgroundImage:selectedImage forState:UIControlStateSelected];

    
}


@end
