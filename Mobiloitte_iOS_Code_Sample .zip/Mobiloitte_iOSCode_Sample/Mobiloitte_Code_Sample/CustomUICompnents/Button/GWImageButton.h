//
//  GWImageButton.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/23/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImage+Tint.h"
@interface GWImageButton : UIButton

@end
