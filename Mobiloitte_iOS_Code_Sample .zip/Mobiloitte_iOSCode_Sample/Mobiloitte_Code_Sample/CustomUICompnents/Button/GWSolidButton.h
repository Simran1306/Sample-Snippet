//
//  GWButton.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWSolidButton : UIButton

- (void)appearanceButton;

@end
