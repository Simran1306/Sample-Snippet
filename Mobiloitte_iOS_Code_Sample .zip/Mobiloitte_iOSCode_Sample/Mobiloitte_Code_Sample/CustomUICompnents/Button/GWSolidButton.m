//
//  GWButton.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWSolidButton.h"

@implementation GWSolidButton

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    return self;
}

-(void)awakeFromNib{
    [super awakeFromNib];
    [self appearanceButton];
}

- (void)appearanceButton {

    UIColor *bgcolor = [self backgroundColor];
    [self setBackgroundColor:[UIColor clearColor]];
    
    UIImage *img ;
    img     = imageFromColor(bgcolor);
    
    
    CGFloat hInset = floorf(img.size.width / 2);
	CGFloat vInset = floorf(img.size.height / 2);
	UIEdgeInsets insets = UIEdgeInsetsMake(vInset, hInset, vInset, hInset);
	img = [img resizableImageWithCapInsets:insets];
    
	[self setBackgroundImage:img forState:UIControlStateNormal];

    CALayer *layer = self.layer;
    layer.backgroundColor = [[UIColor clearColor] CGColor];
    layer.cornerRadius = 5.0;
    layer.masksToBounds = YES;
    
}


@end
