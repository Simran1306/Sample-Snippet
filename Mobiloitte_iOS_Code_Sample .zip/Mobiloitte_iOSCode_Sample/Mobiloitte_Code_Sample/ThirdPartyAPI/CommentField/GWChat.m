//
//  Created by Marat Alekperov (aka Timur Harleev) (m.alekperov@gmail.com) on 18.11.12.
//  Copyright (c) 2012 Me and Myself. All rights reserved.
//


#import "GWChat.h"


@implementation GWChat


- (void) composeView {
    
    CGSize size = self.frame.size;
    
    // Input
	_inputBackgroundView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
	_inputBackgroundView.autoresizingMask = UIViewAutoresizingNone;
    _inputBackgroundView.contentMode = UIViewContentModeScaleToFill;
    _inputBackgroundView.backgroundColor = [UIColor clearColor];
    _inputBackgroundView.image = [[UIImage imageNamed:@"comment_bar.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(22, 0, 22, 0)];
	[self addSubview:_inputBackgroundView];
    
	// Text field
	_textView = [[UITextView alloc] initWithFrame:CGRectMake(12.0f, 0, 240, 0)];
    _textView.backgroundColor = [UIColor clearColor];
	_textView.delegate = self;
    _textView.contentInset = UIEdgeInsetsMake(-4, -2, -4, 0);
    _textView.showsVerticalScrollIndicator = NO;
    _textView.showsHorizontalScrollIndicator = NO;
    _textView.autocorrectionType = UITextAutocorrectionTypeDefault;
	_textView.font = [UIFont systemFontOfSize:15.0f];
	[self addSubview:_textView];
    
    [self adjustTextInputHeightForText:@" " animated:NO];
    
    _lblPlaceholder = [[UILabel alloc] initWithFrame:CGRectMake(20.0f, 10, 240, 20)];
    _lblPlaceholder.font = [UIFont systemFontOfSize:15.0f];
    _lblPlaceholder.text = @"Add a comment...";
    _lblPlaceholder.textColor = [UIColor lightGrayColor];
    _lblPlaceholder.backgroundColor = [UIColor clearColor];
	[self addSubview:_lblPlaceholder];
    
	
	// Send button
	_sendButton = [UIButton buttonWithType:UIButtonTypeCustom];
	_sendButton.frame = CGRectMake(size.width - 60.0f, 6.0f, 54.0f, 31.0f);
	_sendButton.autoresizingMask = UIViewAutoresizingFlexibleTopMargin;
	_sendButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:14];
	_sendButton.titleLabel.shadowOffset = CGSizeMake(0.0f, 1.0f);
    [_sendButton setBackgroundImage:[UIImage imageNamed:@"send_btn.png"] forState:UIControlStateNormal];
	[_sendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_sendButton setTitleColor:[UIColor colorWithWhite:1.0 alpha:0.7] forState:UIControlStateDisabled];
    [_sendButton setTitle:@"Send" forState:UIControlStateNormal];
    [_sendButton setEnabled:NO];

    [_sendButton addTarget:self action:@selector(sendButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
	[self addSubview:_sendButton];
    
    [self sendSubviewToBack:_inputBackgroundView];
}

- (void) awakeFromNib {
   
   _inputHeight = 38.0f;
   _inputHeightWithShadow = 44.0f;
   _autoResizeOnKeyboardVisibilityChanged = YES;

   [self composeView];
}

- (void) adjustTextInputHeightForText:(NSString*)text animated:(BOOL)animated {
   
    if (text.length == 0 || [text isEqualToString:@" "]){
        [_sendButton setEnabled:NO];
    }else{
        [_sendButton setEnabled:YES];
    }
   int h1 = [text sizeWithFont:_textView.font].height;
   int h2 = [text sizeWithFont:_textView.font constrainedToSize:CGSizeMake(_textView.frame.size.width - 16, 170.0f) lineBreakMode:NSLineBreakByCharWrapping].height;
   
   [UIView animateWithDuration:(animated ? .1f : 0) animations:^
    {
       int h = h2 == h1 ? _inputHeightWithShadow : h2 + 24;
       int delta = h - self.frame.size.height;
       CGRect r2 = CGRectMake(0, self.frame.origin.y - delta, self.frame.size.width, h);
       self.frame = r2; //CGRectMake(0, self.frame.origin.y - delta, self.superview.frame.size.width, h);
       _inputBackgroundView.frame = CGRectMake(0, 0, self.frame.size.width, h);
       
       CGRect r = _textView.frame;
       r.origin.y = 8;
       r.size.height = h - 18;
       _textView.frame = r;
       
    } completion:^(BOOL finished)
    {
        if ([_delegate respondsToSelector:@selector(changeHeight:)])
            [_delegate performSelector:@selector(changeHeight:) withObject:_inputBackgroundView];
    }];
}

- (id) initWithFrame:(CGRect)frame {
   
   self = [super initWithFrame:frame];
   
   if (self)
   {
      _inputHeight = 38.0f;
      _inputHeightWithShadow = 44.0f;
      _autoResizeOnKeyboardVisibilityChanged = YES;
      
      [self composeView];
   }
   return self;
}

- (void) fitText {
   
    [self adjustTextInputHeightForText:(_textView.text.length)?_textView.text:@" " animated:YES];
}

- (void) setText:(NSString*)text {
   
   _textView.text = text;
   _lblPlaceholder.hidden = text.length > 0;
   [self fitText];
}


#pragma mark UITextFieldDelegate Delegate

- (void) textViewDidBeginEditing:(UITextView*)textView {
    yOffset = ((self.superview.frame.size.height-self.frame.origin.y) <= 5)?260:216;

   if (_autoResizeOnKeyboardVisibilityChanged)
   {
      [UIView animateWithDuration:.25f animations:^{
         CGRect r = self.frame;
         r.origin.y -= yOffset;
         [self setFrame:r];

      }];
      [self fitText];
   }
   if ([_delegate respondsToSelector:@selector(textViewDidBeginEditing:)])
      [_delegate performSelector:@selector(textViewDidBeginEditing:) withObject:textView];
}

- (void) textViewDidEndEditing:(UITextView*)textView {
    
   if (_autoResizeOnKeyboardVisibilityChanged)
   {
      [UIView animateWithDuration:.25f animations:^{
         CGRect r = self.frame;
         r.origin.y += yOffset;
         [self setFrame:r];

      }];
      
      [self fitText];
   }
   _lblPlaceholder.hidden = _textView.text.length > 0;
   
   if ([_delegate respondsToSelector:@selector(textViewDidEndEditing:)])
      [_delegate performSelector:@selector(textViewDidEndEditing:) withObject:textView];
}

- (BOOL) textView:(UITextView*)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString*)text {
    NSInteger Length = textView.text.length + (text.length - range.length) ;

   if ([text isEqualToString:@"\n"]){
      if ([_delegate respondsToSelector:@selector(returnButtonPressed:)])
         [_delegate performSelector:@selector(returnButtonPressed:) withObject:_textView afterDelay:.1];
      return NO;
   }
    if (Length == 0){
       [_sendButton setEnabled:NO];
    }else{
        [_sendButton setEnabled:YES];
        [self adjustTextInputHeightForText:[NSString stringWithFormat:@"%@%@", _textView.text, text] animated:YES];

    }
    return YES;
}

- (void) textViewDidChange:(UITextView*)textView {
   
    _lblPlaceholder.hidden = _textView.text.length > 0;
   
   [self fitText];
   
   if ([_delegate respondsToSelector:@selector(textViewDidChange:)])
      [_delegate performSelector:@selector(textViewDidChange:) withObject:textView];
}


#pragma mark THChatInput Delegate

- (void) sendButtonPressed:(id)sender {
   
   if ([_delegate respondsToSelector:@selector(sendButtonPressed:)])
      [_delegate performSelector:@selector(sendButtonPressed:) withObject:sender];
}

- (void) showAttachInput:(id)sender {
   
   if ([_delegate respondsToSelector:@selector(showAttachInput:)])
      [_delegate performSelector:@selector(showAttachInput:) withObject:sender];
}

- (void) showEmojiInput:(id)sender {
   
   if ([_delegate respondsToSelector:@selector(showEmojiInput:)])
   {
      if ([_textView isFirstResponder] == NO) [_textView becomeFirstResponder];

      [_delegate performSelector:@selector(showEmojiInput:) withObject:sender];
   }
}

@end
