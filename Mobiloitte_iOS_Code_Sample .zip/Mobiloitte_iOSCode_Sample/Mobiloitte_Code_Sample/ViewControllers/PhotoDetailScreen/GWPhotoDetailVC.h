//
//  GWPhotoDetailVC.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/3/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"
typedef enum _GWPhotoType{
    GWPhoto_Event = 0,
    GWPhoto_Profile = 1,
    GWPhoto_Tagged = 2,
    GWPhoto_Single = 4
}GWPhotoType;

@class GWEventObj;
@interface GWPhotoDetailVC : GAITrackedViewController

@property (nonatomic, strong) IBOutlet UITableView *photoDetailTable;
@property (nonatomic, strong) NSMutableArray *dataArray;
@property (nonatomic, strong) IBOutlet GWChat *commentField;
@property (nonatomic, strong) UIRefreshControl *refreshControl;

@property (nonatomic, assign) BOOL isFromSlider;


// @required
@property (nonatomic, assign) GWPhotoType photoType;

// set user obj if photoType is GWPhoto_Profile or GWPhoto_Tagged
@property (nonatomic, strong) GWUserObj* userObj;

// set event obj if photoType is GWPhoto_Event
@property (nonatomic, strong) GWEventObj* eventObj;

@property (nonatomic, assign) NSInteger selectedIndex;

// set the URL of image which was tapped
// @required in case of 0,1,3
@property (nonatomic, strong) NSString* selectedPhotoURL;

// set photo ID only if photo type is GWPhoto_Single
@property (nonatomic, strong) NSString* photoID;

-(IBAction)commonButtionAction:(id)sender;


@end
