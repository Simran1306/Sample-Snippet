//
//  GWPhotoDetailVC.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/3/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWPhotoDetailVC.h"

@interface GWPhotoDetailVC ()<UIGestureRecognizerDelegate,GWServiceHelperDelegate,GLTapLabelDelegate>

@end

@implementation GWPhotoDetailVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - View Life Cycle  methods

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self prepareNavigationBar];
    
    [self addSwipeGesture];
    
    [self addRefreshControl];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newNotifRecieved:) name:k_Notification_Recieved object:nil];
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self initializaDropDown];
    [self beginRefreshingTable];

}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.trackedViewName = @"Photo Detail Screen";
    [[GWServiceHelper sharedHelper] setServiceHelperDelegate:nil];
    [[GWServiceHelper sharedHelper] cancelRequestwithName:GWService_getPhotoDetail];
    
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

#pragma mark - Instance methods

-(void)initializaDropDown{
    GWNavigationController *nav = (GWNavigationController *)self.navigationController;
    [nav setDataSourceArray:[[NSMutableArray alloc] initWithObjects:@"Report This Photo", nil]];
}

-(void)prepareNavigationBar{
    setNavigationTitle(self, nil,@"Photos");
    
    if (self.isFromSlider) {
        setRevealBarButton(self, [kDef objectForKey:kNotificationCount]);
    }else{
        setleftBarButton(self, @"back_btn.png");
    }
    
    [[self.view viewWithTag:301] setHidden:YES];
    [[self.view viewWithTag:302] setHidden:YES];
    [[self.view viewWithTag:303] setHidden:YES];
}

-(void)addRefreshControl{
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl setTintColor:[[GWAppSettings sharedInstance] app_blueColor]];
    [self.refreshControl addTarget:self action:@selector(reloadTableData:) forControlEvents:UIControlEventValueChanged];
    [self.photoDetailTable addSubview:self.refreshControl];
}

-(void)reloadTableData:(id)sender{
    [self callWebServicesWithHud:NO];
}

-(void)beginRefreshingTable{
    for (id obj in [self.photoDetailTable subviews]) {
        if ([obj isKindOfClass:[UIRefreshControl class]]) {
            if ([self.refreshControl isRefreshing]) {
                return;
            }
            [self.refreshControl beginRefreshing];
            if (self.photoDetailTable.contentOffset.y == 0) {
                
                [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^(void){
                    self.photoDetailTable.contentOffset = CGPointMake(0, -self.refreshControl.frame.size.height);
                } completion:^(BOOL finished){
                }];
                
            }        }
    }
    
    [self reloadTableData:nil];
}


-(void)callWebServicesWithHud:(BOOL)hud{
    self.dataArray = [[NSMutableArray alloc] init];

    switch (self.photoType) {
        case GWPhoto_Event:
        {
            [self callGetPhotoDetailService_withHUD:hud andHUDText:@"Please Wait..." andRequestDict:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",@"0",@"photoType",self.eventObj.eventID,@"eventID",[kDef objectForKey:kUserID],@"myUserID", nil]];

        }
            break;
        case GWPhoto_Profile:{
            [self callGetPhotoDetailService_withHUD:hud andHUDText:@"Please Wait..." andRequestDict:[NSDictionary dictionaryWithObjectsAndKeys:self.userObj.userID,@"userID",@"1",@"photoType",[kDef objectForKey:kUserID],@"myUserID", nil]];

        }
            break;
            
        case GWPhoto_Tagged:{
            [self callGetPhotoDetailService_withHUD:hud andHUDText:@"Please Wait..." andRequestDict:[NSDictionary dictionaryWithObjectsAndKeys:self.userObj.userID,@"userID",@"2",@"photoType",[kDef objectForKey:kUserID],@"myUserID", nil]];
        }
            break;
            
        case GWPhoto_Single:{
            NSString  *userID = [kDef objectForKey:kUserID];
            [self callGetPhotoDetailService_withHUD:hud andHUDText:@"Please Wait..." andRequestDict:[NSDictionary dictionaryWithObjectsAndKeys:userID,@"userID",@"4",@"photoType",self.photoID,@"photoID",userID,@"myUserID", nil]];
        }
            break;

        default:
            break;
    }
}

-(void)callSinglePhotoService{
    NSString  *userID = [kDef objectForKey:kUserID];
    [self callGetPhotoDetailService_withHUD:NO andHUDText:@"Please Wait..." andRequestDict:[NSDictionary dictionaryWithObjectsAndKeys:userID,@"userID",@"4",@"photoType",self.photoID,@"photoID",userID,@"myUserID", nil]];

}

-(void)addSwipeGesture{
    UISwipeGestureRecognizer *leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipeAction:)];
    [leftSwipe setDirection:UISwipeGestureRecognizerDirectionLeft];
    [leftSwipe setDelegate:self];
    [self.photoDetailTable addGestureRecognizer:leftSwipe];
    
    UISwipeGestureRecognizer *rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipeAction:)];
    [rightSwipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [rightSwipe setDelegate:self];

    [self.photoDetailTable addGestureRecognizer:rightSwipe];
}

-(void)updateLikeButton{
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    [(UIButton*)[self.view viewWithTag:302] setSelected:[photoObj.photoIsLikedByMe boolValue]];
    [(UIButton*)[self.view viewWithTag:302] setUserInteractionEnabled:![photoObj.photoIsLikedByMe boolValue]];

}

-(void)newNotifRecieved:(NSNotification*)notif{
    if (self.isFromSlider) {
        setRevealBarButton(self, [kDef objectForKey:kNotificationCount]);
    }
}


-(void)imagePreview:(UITapGestureRecognizer*)gesture{
    
//    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    UITableViewCell *cell = [self.photoDetailTable cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
    
    GGFullscreenImageViewController *vc = [[GGFullscreenImageViewController alloc] init];
    vc.liftedImageView = (UIImageView*)[cell viewWithTag:997];
    [self presentViewController:vc animated:YES completion:nil];
}

#pragma mark - QLPreview delegate methods

#pragma mark - UIGesture delegate methods
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    return YES;
}


#pragma mark - GLTapLabelDelegate
-(void)label:(GLTapLabel *)label didSelectedHotWord:(NSString *)word{

}


#pragma mark - Button Action Methdods
-(void)leftButtonAction:(id)sender{
    [self.view endEditing:YES];
    
    if (self.isFromSlider) {
        [kDef setObject:@"0" forKey:kNotificationCount];
        setRevealBarButton(self, @"0");
    }else{
        GWNavigationController *nav = (GWNavigationController *)self.navigationController;
        if ([nav isMenuOpen]) {
            [nav toggleMenu];
            [self.navigationController performSelector:@selector(popViewControllerAnimated:) withObject:[NSNumber numberWithBool:YES] afterDelay:0.6];
            
            return;
        }
        [self.navigationController popViewControllerAnimated:YES];
    }
    
    
}

-(void)rightButtonAction:(id)sender{
    GWNavigationController *nav = (GWNavigationController *)self.navigationController;
    [nav toggleMenu];
    
    UIButton* but = (UIButton*)sender;
    CGFloat f = [but transform].c;
    
    if (f<0.0) {
        [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            [but setTransform:CGAffineTransformMakeRotation(0)];
            
        } completion:^(BOOL finished) {
        }];
    }else{
        [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            [but setTransform:CGAffineTransformMakeRotation(M_PI_2)];
        } completion:^(BOOL finished) {
        }];
    }
}

-(void)menuButtonPressed:(REMenuItem*)item{
     [GWUtility showaAlertWithTitle:nil andMessage:@"Are you sure you want to report this Photo?" andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
         if (tag == 0) {
             GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
             [self callReportPhotoService_withPhotoID:photoObj.photoID HUD:NO andHUDText:@"Please Wait..."];
         }
    } andCancelButton:@"Report" andOtherButtons:@"Cancel"];
    
}

-(void)menuCompletionHandler{
    UIButton *but = (UIButton *)[[self.navigationItem rightBarButtonItem] customView];
    CGFloat f = [but transform].c;
    
    if (f<0.0) {
        [UIView animateWithDuration:0.2 delay:0.0 options:UIViewAnimationOptionCurveEaseIn animations:^{
            [but setTransform:CGAffineTransformMakeRotation(0)];
            
        } completion:^(BOOL finished) {
        }];
    }
}

-(void)leftSwipeAction:(UISwipeGestureRecognizer*)gesture{
    if (![self.dataArray count]) {
        return;
    }
    if (self.selectedIndex+1 == [self.dataArray count]) {
        self.selectedIndex = 0;
    }else{
        self.selectedIndex += 1;
    }
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    self.selectedPhotoURL = photoObj.photoURL;
    [self updateLikeButton];
    [self.photoDetailTable reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationLeft];
}

-(void)rightSwipeAction:(UISwipeGestureRecognizer*)gesture{
    if (![self.dataArray count]) {
        return;
    }
    if (self.selectedIndex-1 < 0 ) {
        self.selectedIndex = [self.dataArray count]-1;
    }else{
        self.selectedIndex -= 1;
    }
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    self.selectedPhotoURL = photoObj.photoURL;
    [self updateLikeButton];
    [self.photoDetailTable reloadSections:[NSIndexSet indexSetWithIndex:0]  withRowAnimation:UITableViewRowAnimationRight];

}

-(void)commentButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.photoDetailTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.photoDetailTable]];
    if (indexPath == nil) {
        return;
    }
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    GWCommentObj *comment = [photoObj.k_uiarray_detail objectAtIndex:indexPath.row-1];
    if (!comment.userID) {
        return;
    }
    if ([comment.userID isEqualToString:[kDef objectForKey:kUserID]]) {
        GWMyProfileVC *profileVC = [[GWMyProfileVC alloc] initWithNibName:@"GWMyProfileVC" bundle:nil];
        [profileVC setNotFromSlider:YES];
        [self.navigationController pushViewController:profileVC animated:YES];
        profileVC = nil;
    }else{
        GWUserPrfoileVC *userVC = [[GWUserPrfoileVC alloc] initWithNibName:@"GWUserPrfoileVC" bundle:nil];
        [userVC setUserID:comment.userID];
        [self.navigationController pushViewController:userVC animated:YES];
        userVC = nil;
    }
}

-(IBAction)commonButtionAction:(UIButton*)sender{
    switch (sender.tag) {
        case 301:{
            GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
            [self.commentField setCommonRequestingID:photoObj.photoID];
            [self.commentField setAssociatedObj:photoObj];
            [self.commentField.textView becomeFirstResponder];
            
            self.photoID = photoObj.photoID;
            
        }
            break;
        case 302:{
            if ([sender isSelected])
                return;
            GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
            [self callLikePhotoServiceWithPhotoID:photoObj.photoID HUD:NO andHUDText:@"Please Wait..."];
            
            self.photoID = photoObj.photoID;

            
            [sender setSelected:YES];
            [sender setUserInteractionEnabled:NO];
        }
            break;
        case 303:{
            GWCommonFriendListVC *listVC = [[GWCommonFriendListVC alloc] initWithNibName:@"GWCommonFriendListVC" bundle:nil];
            [listVC setListType:GWList_Tag];
            GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
            [listVC setPhotoID:photoObj.photoID];
            
            NSMutableArray *tagArray = [[NSMutableArray alloc] init];
            for (GWUserObj *user in photoObj.phototaggedPeople_array) {
                [tagArray addObject:user.userID];
            }
            [listVC setTagListArray:tagArray];
            [self.navigationController pushViewController:listVC animated:YES];
            listVC = nil;
        }
            break;
        default:
            break;
    }
}

#pragma mark - Drop doen methods
// Send button of comment field
- (void) sendButtonPressed:(id)sender {
    self.commentField.textView.text = self.commentField.textView.text;
    
    [self callCommentOnPhotoService_withComment:self.commentField.textView.text andPhotoID:self.commentField.commonRequestingID HUD:NO andHUDText:@"Please Wait..."];
    
    [self.commentField setCommonRequestingID:@""];
    [self.commentField setAssociatedObj:nil];
    self.commentField.textView.text = @"";
    [self.commentField fitText];
    [self.commentField.textView resignFirstResponder];
}

-(void)returnButtonPressed:(id)sender{
    self.commentField.textView.text = self.commentField.textView.text;
    self.commentField.textView.text = @"";
    [self.commentField setCommonRequestingID:@""];
    [self.commentField setAssociatedObj:nil];
    [self.commentField fitText];
    [self.commentField.textView resignFirstResponder];
}

#pragma mark - UITableViewDataSource Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return ([self.dataArray count])?1:0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    return photoObj.k_rowCount_detail;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    
    switch (indexPath.row) {
        case 0:
        {
            static NSString *detailTextCell = @"detailTextCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:detailTextCell];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailTextCell];
                [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
                
                UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 320)];
                [img setTag:997];
                [img setImage:nil];
                
                UITapGestureRecognizer *gesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imagePreview:)];
                [gesture setDelegate:self];
                [cell addGestureRecognizer:gesture];
                
                [cell addSubview:img];
                
            }
            [(UIImageView*)[cell viewWithTag:997] setImage:nil];
            [(UIImageView*)[cell viewWithTag:997] setImageWithURL:getPhotoURL(photoObj.photoURL) placeholderImage:nil];
            return cell;
        }
            
        default:{
            id objC = [photoObj.k_uiarray_detail objectAtIndex:indexPath.row-1];
            GWBaseObj *baseobj = (GWBaseObj *)objC;
            
            static NSString *tagLikeCell = @"tagLikeCell";
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:tagLikeCell];
            if (cell == nil) {
                cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tagLikeCell];
                [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
                
                UIImageView *img = [[UIImageView alloc] initWithFrame:CGRectMake(15, 3, 24, 24)];
                [img setTag:443];
                [cell addSubview:img];
            
                GLTapLabel *label = [[GLTapLabel alloc] initWithFrame:CGRectMake(44, 5, cell.frame.size.width-54, cell.frame.size.height-8)];
                [label setAutoresizingMask:UIViewAutoresizingFlexibleHeight];
                [label setFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0]];
                [label setNumberOfLines:0];
                [label setTextColor:[[GWAppSettings sharedInstance] app_blueColor]];
                [label setLinkColor:[[GWAppSettings sharedInstance] app_blueColor]];
                [label setTag:444];
                [label setDelegate:self];
                [cell addSubview:label];

            }

            switch (baseobj.type) {
                case GWObject_Like:{
                    [(UIImageView*)[cell viewWithTag:443]setImage:[UIImage imageNamed:@"like_btn.png"]];
                    [(GLTapLabel*)[cell viewWithTag:444] setText:[NSString stringWithFormat:@"%@ Like%@",photoObj.photoLikeCount,(([photoObj.photoLikeCount integerValue]>1)?@"s":@"")]];
                    return cell;
                }
                case GWObject_Tag:{
                    [(UIImageView*)[cell viewWithTag:443] setImage:[UIImage imageNamed:@"tag_btn.png"]];
                    [(GLTapLabel*)[cell viewWithTag:444] setText:photoObj.phototaggedPeople];
                    return cell;
                }
                case GwObject_AllComment:{
                    static NSString *viewAllCell = @"viewAllCell";
                    UITableViewCell* cell_ViewAll = [tableView dequeueReusableCellWithIdentifier:viewAllCell];
                    if (cell_ViewAll == nil) {
                        cell_ViewAll = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:viewAllCell];
                        [cell_ViewAll setSelectionStyle:UITableViewCellSelectionStyleNone];
                        [cell_ViewAll.textLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:12.0]];
                        [cell_ViewAll.textLabel setTextAlignment:NSTextAlignmentCenter];
                        [cell_ViewAll.textLabel setTextColor:[[GWAppSettings sharedInstance] app_darkGreyColor]];
                        
                        UIImageView *divider = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"cell-divider.png"]];
                        [divider setFrame:CGRectMake(24, 1, 272, 1)];
                        [cell_ViewAll.contentView addSubview:divider];
                        
                        
                    }
                    [cell_ViewAll.textLabel setText:[NSString stringWithFormat:@"View all %@ comments",photoObj.photoCommentCount]];
                    return cell_ViewAll;
                }
                    
                default:{
                    static NSString *eventCommentCell = @"eventCommentCell";
                    GWEventCommentCell* cell_comment = (GWEventCommentCell*)[tableView dequeueReusableCellWithIdentifier:eventCommentCell];
                    if (cell_comment == nil) {
                        cell_comment = [[GWEventCommentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:eventCommentCell];
                        [cell_comment setSelectionStyle:UITableViewCellSelectionStyleNone];
                    }
                    GWCommentObj *comment = (GWCommentObj*)objC;
                    [cell_comment setCellUserComment:comment.userComment];
                    [cell_comment.cellImageButton addTarget:self action:@selector(commentButtonTapped:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [cell_comment setCellUserName:comment.userName];
                    [cell_comment setCellUserPhoto:comment.userPhoto];
                    [cell_comment layoutFrames];
                    
                    return cell_comment;
                }
            }
        }
    }
}

#pragma mark - UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 30.0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectZero];
    [view setBackgroundColor:[UIColor clearColor]];
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    CBAutoScrollLabel *leftLabel = nil;
    UILabel *rightLabel = nil;
    
    static NSString *cellHeader = @"cellHeader";
    UIView *view  = [tableView dequeueReusableHeaderFooterViewWithIdentifier:cellHeader];
    if (view == nil) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 35.0)];
        [view setBackgroundColor:[[GWAppSettings sharedInstance] app_lightGreyColor]];
        
        leftLabel =   [[CBAutoScrollLabel alloc] initWithFrame:CGRectMake(10, 0, 150, view.frame.size.height)];
        [leftLabel setScrollDirection:CBAutoScrollDirectionLeft];
        [leftLabel observeApplicationNotifications];
        leftLabel.textAlignment = NSTextAlignmentLeft;
        [leftLabel setTextColor:[[GWAppSettings sharedInstance] app_blueColor]];
        [leftLabel setBackgroundColor:[UIColor clearColor]];
        [leftLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaNeueMediumWithSize:14.0]];
        [view addSubview:leftLabel];
        
        rightLabel = [[UILabel alloc] initWithFrame:CGRectMake((leftLabel.frame.origin.x+leftLabel.frame.size.width)+5, 0, 150, view.frame.size.height)];
        [rightLabel setTextColor:[[GWAppSettings sharedInstance] app_blueColor]];
        [rightLabel setBackgroundColor:[UIColor clearColor]];
        [rightLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:12.0]];
        [rightLabel setTextAlignment:NSTextAlignmentRight];
        
        [view addSubview:rightLabel];
    }
    
    if (self.photoType == GWPhoto_Single) {
        [leftLabel setText:photoObj.photoTypeName];
        
    }else{
        [leftLabel setText:(self.eventObj)?self.eventObj.eventName:self.userObj.userName];
    }
    [rightLabel setText:photoObj.photoTimeString_UI];
    

    return view;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    GWBaseObj *baseobj;
    
    switch (indexPath.row) {
        case 0:{
        }
            break;

        default:{
            if ([photoObj.k_uiarray_detail count]>0) {
                baseobj = [photoObj.k_uiarray_detail objectAtIndex:indexPath.row-1];
            }
            if (baseobj.type == GwObject_AllComment) {
                GWCommentVC *commentVC = [[GWCommentVC alloc] initWithNibName:@"GWCommentVC" bundle:nil];
                [commentVC setPhotoID:photoObj.photoID];
                [self.navigationController pushViewController:commentVC animated:YES];
                commentVC = nil;
            }
        }
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    GWPhotoObj *photoObj = [self.dataArray objectAtIndex:self.selectedIndex];
    
    
    switch (indexPath.row) {
        case 0:
            return 320.0;
            
        default:{
            id Obj = nil;
            GWBaseObj *baseobj;
            
            if ([photoObj.k_uiarray_detail count]>0) {
                Obj = [photoObj.k_uiarray_detail objectAtIndex:indexPath.row-1];
            }
            baseobj = (GWBaseObj*)Obj;
            switch (baseobj.type) {
                case GWObject_Like:
                case GwObject_AllComment:
                    return 30.0;
                

                case GWObject_Tag:
                    return [photoObj k_rowSize_Tag];
                default:
                    return [(GWCommentObj*)Obj k_rowSize_Home];
            }
        }
    }

}

#pragma mark - GWService Heleper  methods

-(void)callGetPhotoDetailService_withHUD:(BOOL)showHUD andHUDText:(NSString*)HUDText andRequestDict:(NSDictionary*)dict{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:NO dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper cancelRequestwithName:GWService_getPhotoDetail];
    [helper setServiceHelperDelegate:self];
    
    [helper callPOSTMethodWithData:dict andMethodName:GWService_getPhotoDetail];
}

-(void)callCommentOnPhotoService_withComment:(NSString*)comment andPhotoID:(NSString*)photoID HUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:NO dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",photoID,@"photoID",@"1",@"commentType",[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]],@"time",comment,@"comment", nil] andMethodName:GWService_addComment];
}


-(void)callReportPhotoService_withPhotoID:(NSString*)photoID HUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:NO dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"reportingUserID",photoID,@"photoID",@"0",@"reportType", nil] andMethodName:GWService_reportEPH];
}

-(void)callLikePhotoServiceWithPhotoID:(NSString *)photoID HUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",photoID,@"photoID", nil] andMethodName:GWService_likePhoto];
}

#pragma mark - GWService Heleper Delegte methods
-(void)serviceResponse:(id)response andMethodName:(GWServiceMethod)methodName{
    [MBProgressHUD hideAllHUDsForView:[[UIApplication sharedApplication] keyWindow] animated:NO];

    switch (methodName) {
        case GWService_getPhotoDetail:{
            for (NSDictionary *dict in [response objectForKey:@"photoList"]) {
                GWPhotoObj *photoObj = [GWPhotoObj photoFromDict:dict];
                
                if ([self.dataArray containsObject:photoObj]) {
                    [self.dataArray replaceObjectAtIndex:[self.dataArray indexOfObject:photoObj] withObject:photoObj];
                }else{
                    [self.dataArray addObject:photoObj];
                }
                
                if (self.selectedPhotoURL) {
                    if ([photoObj.photoURL isEqualToString:self.selectedPhotoURL]) {
                        self.selectedIndex = [self.dataArray indexOfObject:photoObj];
                    }
                }else{
                    self.selectedIndex = 0;
                }
            }
            [self updateLikeButton];
            setRightBarButton(self, @"delete_btn.png");
            
            [[self.view viewWithTag:301] setHidden:NO];
            [[self.view viewWithTag:302] setHidden:NO];
            [[self.view viewWithTag:303] setHidden:NO];
            [self.photoDetailTable reloadData];
            for (id obj in [self.photoDetailTable subviews]) {
                if ([obj isKindOfClass:[UIRefreshControl class]]) {
                    [self.refreshControl endRefreshing];
                    [self.refreshControl setAttributedTitle:nil];
                    [self.refreshControl removeFromSuperview];
                }
            }

            
        }
            break;
        case GWService_addComment:{
            [self callSinglePhotoService];

        }
            break;
            
        case GWService_likePhoto:{
            [self callSinglePhotoService];
        }
            break;
            
        case GWService_reportEPH:{
            [GWUtility showaAlertWithTitle:nil andMessage:[response objectForKey:@"responseMessage"] andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
                
            } andCancelButton:nil andOtherButtons:@"OK"];
            [self callWebServicesWithHud:NO];
        }
            break;
        
        default:
            break;
    }

}

-(void)connectionFailWithError:(NSString *)error andMethodName:(GWServiceMethod)methodName{
    [MBProgressHUD hideAllHUDsForView:[[UIApplication sharedApplication] keyWindow] animated:NO];
    removeRightBarButtonItem(self);
    
    [[self.view viewWithTag:301] setHidden:YES];
    [[self.view viewWithTag:302] setHidden:YES];
    [[self.view viewWithTag:303] setHidden:YES];
    [self.refreshControl endRefreshing];
    
    if ([error isEqualToString:kNetworkErrorMessage]) {
        [self.refreshControl setAttributedTitle:[[NSAttributedString alloc] initWithString:@"Check your connection and try again" attributes:[NSDictionary dictionaryWithObjectsAndKeys:[[GWAppSettings sharedInstance] app_darkGreyColor],NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica-Regilar" size:12.0],NSFontAttributeName, nil]]];
        [self.refreshControl performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.5];
    }else{
        [self.refreshControl endRefreshing];
        [self.refreshControl setAttributedTitle:nil];
        [GWUtility showaAlertWithTitle:@"Error!" andMessage:error andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
            
        } andCancelButton:nil andOtherButtons:@"OK"];

    }
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    self.dataArray = nil;
    self.refreshControl = nil;
    self.userObj = nil;
    self.eventObj = nil;

    self.photoDetailTable.delegate = nil;
    self.photoDetailTable.dataSource = nil;
    self.photoDetailTable = nil;
}

@end
