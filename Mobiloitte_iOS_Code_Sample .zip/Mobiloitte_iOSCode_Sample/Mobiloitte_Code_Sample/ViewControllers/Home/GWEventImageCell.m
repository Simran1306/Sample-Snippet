//
//  GWEventImageCell.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWEventImageCell.h"

@implementation GWEventImageCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        [self initiliazeCarousel];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)initiliazeCarousel{
    
    self.cellDivider = [[UIImageView alloc] initWithFrame:CGRectMake(24, 8, 272, 1)];
    [self.cellDivider setImage:[UIImage imageNamed:@"cell-divider.png"]];
    [self.contentView addSubview:self.cellDivider];
    
    
    _carousel = [[iCarousel alloc] initWithFrame:self.bounds];
	_carousel.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _carousel.type = iCarouselTypeRotary;
	_carousel.delegate = self;
	_carousel.dataSource = self;
    _carousel.clipsToBounds = YES;
    
	//add carousel to view
	[self.contentView addSubview:_carousel];
}

-(void)setDataSource:(NSArray*)array{
    _items = [[NSMutableArray alloc] initWithArray:array];
    [_carousel reloadData];
}

#pragma mark -
#pragma mark iCarousel methods

- (NSUInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return [_items count];
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSUInteger)index reusingView:(UIView *)view
{
//    UILabel *label = nil;
    
    //create new view if no view is available for recycling
    if (view == nil){
        view = (GWRoundedImageView*)[[GWRoundedImageView alloc] initWithFrame:CGRectMake(0, 0, 160.0f, 160.0f)];
        [(GWRoundedImageView*)view setContentMode:UIViewContentModeScaleToFill];
        [view.layer setCornerRadius:5.0];
        [view.layer setMasksToBounds:YES];
        [view.layer setBorderWidth:1.0];
        [view.layer setBorderColor:[[UIColor darkGrayColor] CGColor]];

    }
    else{
    }
    GWPhotoObj *photo = [_items objectAtIndex:index];
    [((GWRoundedImageView *)view) setImageWithURL:getPhotoURL(photo.photoURL) ];
    return view;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {
    if ([self.carouselDelegate respondsToSelector:@selector(carouselDidTapItemAtIndex:withTableIndexPath:)] && self.carouselDelegate) {
        [self.carouselDelegate carouselDidTapItemAtIndex:index withTableIndexPath:self.indexPath];
    }
}



@end
