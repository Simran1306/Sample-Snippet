//
//  GWEventImageCell.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"
#import "iCarousel.h"

@protocol carouselDelegate;


@interface GWEventImageCell : UITableViewCell<iCarouselDataSource,iCarouselDelegate>

@property (nonatomic, strong) NSMutableArray *items;

@property (nonatomic, strong) iCarousel *carousel;

@property (nonatomic, assign) id<carouselDelegate> carouselDelegate;

@property (nonatomic, strong) UIImageView *cellDivider;

@property (nonatomic, strong) NSIndexPath *indexPath;

-(void)setDataSource:(NSArray*)array;

@end


@protocol carouselDelegate <NSObject>

- (void)carouselDidTapItemAtIndex:(NSInteger)index withTableIndexPath:(NSIndexPath*)indexPath;

@end