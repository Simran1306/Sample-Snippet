//
//  GWEventCommentCell.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWEventCommentCell.h"

@implementation GWEventCommentCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initializeLayout];

    }
    
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)layoutFrames{
    UILabel* cmntLabel = ( UILabel* )[self viewWithTag:22];
    NSString *completeString = [NSString stringWithFormat:@"%@ : %@",self.cellUserName,self.cellUserComment];

    [self.cellImageButton setBackgroundImageWithURL:getPhotoURL(self.cellUserPhoto) placeholderImage:[UIImage imageNamed:@"placeholder.png"] forState:UIControlStateNormal];
    [cmntLabel setAttributedText:[self getAttributedString:self.cellUserName andComment:self.cellUserComment]];
    CGSize sizeHome = [completeString sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:13.0] constrainedToSize:CGSizeMake(240, MAXFLOAT)];
    [cmntLabel setFrame:CGRectMake(55, 3, 240, sizeHome.height+2)];


}

-(void)initializeLayout{
    self.cellImageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.cellImageButton setFrame:CGRectMake(15, 3, 34, 34)];
    [self.cellImageButton.layer setCornerRadius:5.0];
    [self.cellImageButton.layer setMasksToBounds:YES];
    [self.cellImageButton setTag:21];
    [self addSubview:self.cellImageButton];
     
    UILabel *commentLabel = [[UILabel alloc] initWithFrame:CGRectMake(55, 3, 240, self.frame.size.height-20)];
    [commentLabel setNumberOfLines:0];
    [commentLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:13.0]];
    [commentLabel setTag:22];

    [self addSubview:commentLabel];
}


-(NSAttributedString*)getAttributedString:(NSString*)nameString andComment:(NSString*)commentString{
    NSString *completeString = [NSString stringWithFormat:@"%@ : %@",nameString,commentString];
    NSInteger nameLength = [nameString length];
    
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:completeString];
    [string addAttribute:NSForegroundColorAttributeName value:[[GWAppSettings sharedInstance] app_blueColor] range:NSMakeRange(0, nameLength)];
    [string addAttribute:NSForegroundColorAttributeName value:[UIColor blackColor] range:NSMakeRange(nameLength, completeString.length - nameLength)];
    [string addAttribute:NSFontAttributeName value:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:13.0] range:NSMakeRange(0, completeString.length)];

    return string;
}

@end
