//
//  GWEventCommentCell.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWEventCommentCell : UITableViewCell

@property (nonatomic, strong) NSString *cellUserName;

@property (nonatomic, strong) NSString *cellUserComment;

@property (nonatomic, strong) NSString *cellUserPhoto;

@property (nonatomic, strong) UIButton *cellImageButton;


-(void)layoutFrames;

@end
