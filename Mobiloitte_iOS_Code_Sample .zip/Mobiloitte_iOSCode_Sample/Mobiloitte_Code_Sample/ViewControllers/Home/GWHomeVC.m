//
//  GWHomeVC.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWHomeVC.h"

@interface GWHomeVC ()<UITableViewDataSource,UITableViewDelegate,carouselDelegate,GWServiceHelperDelegate>{
    NSInteger pageNumber_unlv;
    BOOL isMaxPage_unlv;
    BOOL isLoadMoreExecuting_unlv;
    
    NSInteger pageNumber_friends;
    BOOL isMaxPage_friends;
    BOOL isLoadMoreExecuting_friends;

    BOOL tempListFilter;

    
    CGPoint previousOffset;
    GWEventObj *selectedEvent;
}

@end

@implementation GWHomeVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

#pragma mark - View Life Cycle  methods

- (void)viewDidLoad{
    [super viewDidLoad];
    
    [self prepareNavigationBar];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateHome) name:kNotif_ShouldUpdateHome object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(eventDeletedUpdate:) name:kNotif_UpdateHomeAfterDelete object:nil];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(newNotifRecieved:) name:k_Notification_Recieved object:nil];
    
    if ([self respondsToSelector:@selector(edgesForExtendedLayout)]) {
        [self setEdgesForExtendedLayout:UIRectEdgeNone];
    }
    
    [self addPullToRefresh];
    
    self.shouldUpdate = YES;

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.trackedViewName = @"Event Feed Screen";
    [CBAutoScrollLabel controllerViewAppearing:self];

    
    [self.view endEditing:YES];
    
    [self initializaDropDown];
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
    
    [self checkAndShowFirstTimeAlert];
    
    [self checkAndShowAndroidAppAlert];
    
    if (![kDef objectForKey:kUserID] || ![[kDef objectForKey:kUserProfileIsComplete] boolValue]) {
        [self goToLogin];
    }else{
        if (self.sidePanelController.state == JASidePanelLeftVisible) {
            return;
        }
        if (!self.shouldUpdate) {
            return;
        }
        self.shouldUpdate = NO;
        if (self.listFilter.integerValue) {
            pageNumber_friends = 1;
        }else{
            pageNumber_unlv = 1;
        }
        
        [self beginRefreshingTable];
    }
    

}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];

}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[GWServiceHelper sharedHelper] setServiceHelperDelegate:nil];
}

- (void)viewDidUnload {
    [super viewDidUnload];
}

#pragma mark - Instance methods
/**
 ** Method for initialising data source for dropdown
 **/
-(void)initializaDropDown{
    GWNavigationController *nav = (GWNavigationController *)self.navigationController;
    [nav setDataSourceArray:[[NSMutableArray alloc] initWithObjects:@"Parties",@"Sports & Games",@"Music",@"Organizations",@"Food",@"Misc.",@"All Categories", nil]];
}

-(void)checkAndShowFirstTimeAlert{
    if ([kDef objectForKey:kUserFirstTimeRegistered] && [[kDef objectForKey:kUserFirstTimeRegistered] isEqualToString:@"1"] ) {
        [kDef setObject:@"0" forKey:kUserFirstTimeRegistered];
        [kDef setObject:@"0" forKey:kUser_AndroidAppAlert];

        [GWUtility showaAlertWithTitle:@"Welcome to Demo!" andMessage:kHomeAlertMsg1 andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
            
            [GWUtility showaAlertWithTitle:@"Welcome to Demo!" andMessage:kHomeAlestMsg2 andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
                
            } andCancelButton:nil andOtherButtons:@"OK"];
        } andCancelButton:nil andOtherButtons:@"Next"];
    }
}

-(void)checkAndShowAndroidAppAlert{
    if ([kDef objectForKey:kUserID] && [[kDef objectForKey:kUser_AndroidAppAlert] isEqualToString:@"1"]) {
        [kDef setObject:@"0" forKey:kUser_AndroidAppAlert];
        [GWUtility showaAlertWithTitle:@"Welcome to Demo!" andMessage:kHomeAlertMsg1 andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
            
            [GWUtility showaAlertWithTitle:@"Welcome to Demo!" andMessage:kHomeAlestMsg2 andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
                
            } andCancelButton:nil andOtherButtons:@"OK"];
        } andCancelButton:nil andOtherButtons:@"Next"];
    }

}

-(UIView*)endFooterView{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 25)];
    [view setBackgroundColor:[UIColor clearColor]];
    return view;
}

-(UIView*)loadMoreFooterView{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 70)];
    [view setBackgroundColor:[UIColor clearColor]];
    
    UIActivityIndicatorView *activity = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [activity setHidesWhenStopped:YES];
    [view addSubview:activity];
    [activity setCenter:CGPointMake(view.center.x, view.center.y - 10)];
    [activity startAnimating];

    return view;
}

-(void)updateHome{
    self.shouldUpdate = YES;
}

-(void)eventDeletedUpdate:(NSNotification*)notif{
    GWEventObj *eventObj = notif.object;
    if ([self.unlv_dataArray containsObject:eventObj]) {
        [self.unlv_dataArray removeObject:eventObj];
    }
    if ([self.friends_dataArray containsObject:eventObj]) {
        [self.friends_dataArray removeObject:eventObj];
    }
    [self.homeTable reloadData];
}

-(void)addPullToRefresh{   
    UITableViewController *tableViewController = [[UITableViewController alloc] init];
    tableViewController.tableView = self.homeTable;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    [self.refreshControl addTarget:self action:@selector(reloadTableData:) forControlEvents:UIControlEventValueChanged];
    tableViewController.refreshControl = self.refreshControl;
    
}

-(void)reloadTableData:(UIRefreshControl*)control{
    if (self.listFilter.integerValue) {
        pageNumber_friends = 1;
    }else{
        pageNumber_unlv = 1;
    }
    [self callGetEventFeedService_withHUD:NO andHUDText:@"Please Wait..."];
}

-(void)beginRefreshingTable{
    if ([self.refreshControl isRefreshing]) {
        return;
    }
    [self.refreshControl beginRefreshing];
    if (self.homeTable.contentOffset.y == 0) {
        
        [UIView animateWithDuration:0.25 delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^(void){
            self.homeTable.contentOffset = CGPointMake(0, -self.refreshControl.frame.size.height);
        } completion:^(BOOL finished){
        }];
        
    }
    [self reloadTableData:nil];
}

/**
 ** Method for presenting login view controller
 **/
-(void)goToLogin{
    
    GWSignUpVC *signUpVC = [[GWSignUpVC alloc] initWithNibName:@"GWSignUpVC" bundle:nil];
    UINavigationController *tempNav = [[UINavigationController alloc] initWithRootViewController:signUpVC];
    [tempNav.navigationItem setHidesBackButton:YES animated:NO];
    [self.navigationController presentViewController:tempNav animated:NO completion:^{
        
    }];
}

/**
 ** Method for preparing navigation items
 **/
-(void)prepareNavigationBar{
    setNavigationTitle(self, @"header-logo.png",nil);
    setRevealBarButton(self, [kDef objectForKey:kNotificationCount]);
    setRightBarButtonForHome(self, @"all_categories.png");
    
    UIButton *unlv = (UIButton *)[self.view viewWithTag:301];
    [unlv setSelected:YES];
    
    pageNumber_unlv = 1;
    pageNumber_friends = 1;
    self.categoryFilter = @"0";
    self.listFilter = @"0";
    self.unlv_dataArray = [[NSMutableArray alloc] init];
    self.friends_dataArray = [[NSMutableArray alloc] init];
    
    [self.noDataLabel setText:kNoData_home];
    
}

-(void)newNotifRecieved:(NSNotification*)notif{
    setRevealBarButton(self, [kDef objectForKey:kNotificationCount]);
}

#pragma mark - Button Action Methdods
-(void)leftButtonAction:(id)sender{
     [self.view endEditing:YES];
    GWNavigationController *nav = (GWNavigationController *)self.navigationController;
    if ([nav isMenuOpen]) {
        [nav toggleMenu];
        return;
    }
    [kDef setObject:@"0" forKey:kNotificationCount];
    setRevealBarButton(self, @"0");
}

-(void)rightButtonAction:(id)sender{
    GWNavigationController *nav = (GWNavigationController *)self.navigationController;
    [nav toggleMenu];
}

-(IBAction)commonButtionAction:(id)sender{

    UIButton *button = (UIButton*)sender;
    if ([button isSelected]) {
        return;
    }
    UIButton *unlv = (UIButton *)[self.view viewWithTag:301];
    UIButton *friends = (UIButton *)[self.view viewWithTag:303];
    
    
    if (self.listFilter.integerValue) {
        pageNumber_friends = 1;

    }else{
        pageNumber_unlv = 1;

    }
    
    if (button.tag == 301) {
        [unlv setSelected:YES];
        [friends setSelected:NO];
        self.listFilter = @"0";
        [self.noDataLabel setHidden:self.unlv_dataArray.count];
        (isMaxPage_unlv)?[self.homeTable setTableFooterView:[self endFooterView]]:[self.homeTable setTableFooterView:[self loadMoreFooterView]];

    }else{
        [unlv setSelected:NO];
        [friends setSelected:YES];
        self.listFilter = @"1";
        [self.noDataLabel setHidden:self.friends_dataArray.count];
        (isMaxPage_friends)?[self.homeTable setTableFooterView:[self endFooterView]]:[self.homeTable setTableFooterView:[self loadMoreFooterView]];

    }
    [self.homeTable setContentOffset:CGPointZero animated:NO];
    [self.homeTable reloadData];

}

-(IBAction)centerButtionAction:(UIButton*)sender{

    GWCreateEventVC *createEventVC = [[GWCreateEventVC alloc] initWithNibName:@"GWCreateEventVC" bundle:nil];
    UINavigationController *tempNav = [[UINavigationController alloc] initWithRootViewController:createEventVC];
    
    GWFormSheetController *formSheet = [[GWFormSheetController alloc] initWithSize:CGSizeMake(260, 450) viewController:tempNav];
    formSheet.transitionStyle = GWFormSheetTransitionStyleSlideFromBottom;
    formSheet.portraitTopInset = self.navigationController.view.frame.size.height-450;
    [formSheet presentAnimated:YES completionHandler:^(UIViewController *presentedFSViewController) {
        
    }];
    
    createEventVC = nil;
    tempNav = nil;
}

-(void)rsvpButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.homeTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.homeTable]];
    if (indexPath == nil) {
        return;
    }
    
    [GWUtility showaAlertWithTitle:nil andMessage:@"Are you sure you want to RSVP to this event?" andSubtitle:@"Post this event to my profile:" andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
        if (tag == 0) {
            GWEventObj *eventObj = nil;
            if (self.listFilter.integerValue) {
                eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
            }else{
                eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
            }
            selectedEvent = eventObj;
            
            [button setSelected:YES];
            [button setUserInteractionEnabled:NO];
            
            [self callRSVPService_withPostOnProfile:[NSString stringWithFormat:@"%d",subtitleSelected] andEventID:eventObj.eventID HUD:NO andHUDText:@"Please Wait..."];
            
            [eventObj setEventRSPVed:@"1"];
            [self.unlv_dataArray replaceObjectAtIndex:indexPath.section withObject:eventObj];
        }
    } andCancelButton:@"Yes" andOtherButtons:@"No"];
    
}

-(void)imageButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.homeTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.homeTable]];
    if (indexPath == nil) {
        return;
    }
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    if ([eventObj.eventCreatorID isEqualToString:[kDef objectForKey:kUserID]]) {
        GWMyProfileVC *profileVC = [[GWMyProfileVC alloc] initWithNibName:@"GWMyProfileVC" bundle:nil];
        [profileVC setNotFromSlider:YES];
        [self.navigationController pushViewController:profileVC animated:YES];
        profileVC = nil;
    }else{
        GWUserPrfoileVC *userVC = [[GWUserPrfoileVC alloc] initWithNibName:@"GWUserPrfoileVC" bundle:nil];
        [userVC setUserID:eventObj.eventCreatorID];
        [self.navigationController pushViewController:userVC animated:YES];
        userVC = nil;
    }

    
}

-(void)attendeeButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.homeTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.homeTable]];
    if (indexPath == nil) {
        return;
    }
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    
    if ([eventObj.eventAttendees integerValue] == 0) {
        return;
    }
    GWCommonFriendListVC *attendeeVC = [[GWCommonFriendListVC alloc] initWithNibName:@"GWCommonFriendListVC" bundle:nil];
    [attendeeVC setEventID:eventObj.eventID];
    [attendeeVC setListType:GWList_Attendees];
    [self.navigationController pushViewController:attendeeVC animated:YES];
    attendeeVC = nil;
    
}

-(void)commentButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.homeTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.homeTable]];
    if (indexPath == nil) {
        return;
    }
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
       eventObj =  [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
       eventObj =  [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    GWCommentObj *comment = [eventObj.k_uiarray objectAtIndex:indexPath.row-1];
    if (!comment.userID) {
        return;
    }
    if ([comment.userID isEqualToString:[kDef objectForKey:kUserID]]) {
        GWMyProfileVC *profileVC = [[GWMyProfileVC alloc] initWithNibName:@"GWMyProfileVC" bundle:nil];
        [profileVC setNotFromSlider:YES];
        [self.navigationController pushViewController:profileVC animated:YES];
        profileVC = nil;
    }else{
        GWUserPrfoileVC *userVC = [[GWUserPrfoileVC alloc] initWithNibName:@"GWUserPrfoileVC" bundle:nil];
        [userVC setUserID:comment.userID];
        [self.navigationController pushViewController:userVC animated:YES];
        userVC = nil;
    }
}


-(void)headerButtonTapped:(UIControl *) button withEvent:(UIEvent *) event {
    
    NSIndexPath * indexPath = [self.homeTable indexPathForRowAtPoint: [[[event touchesForView: button] anyObject] locationInView: self.homeTable]];
    if (indexPath == nil) {
        return;
    }
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
       eventObj =  [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
       eventObj =  [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    GWEventDetailVC *detailVC = [[GWEventDetailVC alloc] initWithNibName:@"GWEventDetailVC" bundle:nil];
    [detailVC setEventID:eventObj.eventID];
    [self.navigationController pushViewController:detailVC animated:YES];
    detailVC = nil;
}

-(void)headerImageTapepd:(UIButton*)sender{
    [self.homeTable setContentOffset:CGPointZero animated:YES];
}

#pragma mark - Dropdown methods
-(void)menuButtonPressed:(REMenuItem*)item{
    if (item.tag == 6) {
        self.categoryFilter = @"0";
    }else{
        self.categoryFilter = [NSString stringWithFormat:@"%d",item.tag+1];
    }
    if (self.listFilter.integerValue) {
        pageNumber_friends = 1;
    }  else{
        pageNumber_unlv =  1;
    }
    
    [self.homeTable setContentOffset:CGPointZero animated:NO];
    [self performSelector:@selector(beginRefreshingTable) withObject:nil afterDelay:0.1];

    setRightBarButtonForHome(self, [NSString stringWithFormat:@"%@.png",[[item.title lowercaseString] stringByReplacingOccurrencesOfString:@" " withString:@"_"]]);
}

-(void)menuCompletionHandler{
    
}

#pragma mark - Chat Field Methods
// Send button of comment field
- (void) sendButtonPressed:(id)sender {
    self.commentField.textView.text = self.commentField.textView.text;

    [self callCommentOnEventService_withComment:self.commentField.textView.text andEventID:self.commentField.commonRequestingID HUD:NO andHUDText:@"Please Wait..."];

    self.commentField.commonRequestingID = @"";
    self.commentField.associatedObj = nil;
    self.commentField.textView.text = @"";
    [self.commentField fitText];
    
    [self removeOverlayAnimated];
    [self.commentField.textView resignFirstResponder];
}

-(void)returnButtonPressed:(id)sender{
    self.commentField.textView.text = self.commentField.textView.text;
    self.commentField.textView.text = @"";
    self.commentField.associatedObj = nil;

    [self.commentField fitText];
    self.commentField.commonRequestingID = @"";

    
    [self removeOverlayAnimated];
    [self.commentField.textView resignFirstResponder];
    [self.commentField.textView resignFirstResponder];
}

/**
 ** Method for adding an animated black overlay
 **/
-(void)addOverlayAnimated{
    UIView *overLay = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    [overLay setBackgroundColor:[UIColor colorWithWhite:0.0 alpha:0.5]];
    [overLay setAlpha:0.0];
    [overLay setTag:997];
    [self.view.window addSubview:overLay];
    
    [UIView animateWithDuration:0.3 animations:^{
        [overLay setAlpha:1.0];
        
    } completion:^(BOOL finished) {
        CGRect frame = overLay.frame;
        frame.size.height = [UIScreen mainScreen].bounds.size.height-(216+41);
        overLay.frame = frame;
    }];
}
/**
 ** Method for removing animated black overlay
 **/
-(void)removeOverlayAnimated{
    UIView *overLay = [self.view.window viewWithTag:997];
    [overLay setFrame:[[UIScreen mainScreen] bounds]];
    [UIView animateWithDuration:0.3 animations:^{
        [overLay setAlpha:0.0];
        
    } completion:^(BOOL finished) {
        [overLay removeFromSuperview];
    }];
}

-(void)changeHeight:(UIImageView*)v{
    UIView *overLay = [self.view.window viewWithTag:997];

    CGRect frame = overLay.frame;
    frame.size.height = [UIScreen mainScreen].bounds.size.height-(216+v.frame.size.height);
    overLay.frame = frame;

}

#pragma mark - Event detail cell delegate method

-(void)MenuBottonTappedWithIndex:(NSIndexPath *)index andButtonIndex:(NSInteger)idx{
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:index.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:index.section];
    }
    
    selectedEvent = eventObj;

    switch (idx) {
        case 0:{
            [self addOverlayAnimated];
            [self.commentField setCommonRequestingID:eventObj.eventID];
            [self.commentField setAssociatedObj:eventObj];
            [self.commentField.textView becomeFirstResponder];
        }
            break;
        case 1:{
            __block UIImage *uploadImage = nil;
            
            [GWUtility showaActionSheetWithTitle:@"Upload Photo"
                                      andMessage:nil
                                 andButtonAction:^(int tag, SIActionSheetButtonType type) {
                                     
                                     if (tag == 0) {
                                         return ;
                                     }
                                     if (![eventObj.eventRSPVed boolValue]) {
                                         [GWUtility showaAlertWithTitle:@"Sorry!" andMessage:@"You can not upload a photo to this event unless you are attending it." andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
                                             
                                         } andCancelButton:nil andOtherButtons:@"OK"];
                                         return;
                                     }
                                     if (tag == 1) {
                                         [[GWImagePickerController sharedManager] openCameraWithSelectedImage:^(UIImage *image) {
                                             uploadImage = image;
                                             [self callUploadPhotoWithImage:image andEventID:eventObj.eventID withHUD:NO andHUDText:@"Please Wait..."];
                                             
                                         } fromController:self];
                                         
                                     }
                                     if(tag == 2){
                                         [[GWImagePickerController sharedManager] openPhotoLibraryWithSelectedImage:^(UIImage *image) {
                                             uploadImage = image;
                                             [self callUploadPhotoWithImage:image andEventID:eventObj.eventID withHUD:NO andHUDText:@"Please Wait..."];
                                             
                                         } fromController:self];
                                     }
                                     
                                 }
                                 andCancelButton:@"Cancel"
                                 andOtherButtons:@"Take from Camera",@"Choose from Library", nil];
        }
            break;
        default:{
            [GWUtility showaActionSheetWithTitle:@"Share Using..."
                                      andMessage:nil
                                 andButtonAction:^(int tag, SIActionSheetButtonType type) {
                                     UIImageView *tempView = [[UIImageView alloc] init];
                                     [tempView setImageWithURL:getPhotoURL(eventObj.eventCreatorPhoto)];
                                     
                                     if (tag == 1) {
                                         
                                         [[GWComposer sharedManager] postOnFacebook:[NSString stringWithFormat:@"%@\n\n%@",eventObj.eventDetail,kSocialText] andImage:tempView.image];
                                     }else if (tag == 2){
                                         [[GWComposer sharedManager] postOnTwitter:[NSString stringWithFormat:@"%@\n\n%@",eventObj.eventDetail,kSocialText] andImage:tempView.image];
                                     }
                                     else if (tag == 3){
                                         [[GWComposer sharedManager] sendMailWithSubject:[NSString stringWithFormat:@"%@\n\n%@",eventObj.eventDetail,kSocialText] andBody:eventObj.eventDetail recepients:[NSArray array]];
                                     }else{
                                         
                                     }
                                 }
                                 andCancelButton:@"Cancel"
                                 andOtherButtons:@"Facebook",@"Twitter",@"Email", nil];
        }
            break;
    }
    
    
}

#pragma mark - Carousel Delegate method
-(void)carouselDidTapItemAtIndex:(NSInteger)index withTableIndexPath:(NSIndexPath *)indexPath{
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    GWPhotoObj *photoObj = [eventObj.eventPhotoList objectAtIndex:index];
    
    GWPhotoDetailVC *detailVC = [[GWPhotoDetailVC alloc] initWithNibName:@"GWPhotoDetailVC" bundle:nil];
    [detailVC setPhotoType:GWPhoto_Event];
    [detailVC setEventObj:eventObj];
    [detailVC setSelectedPhotoURL:photoObj.photoURL];

    [self.navigationController pushViewController:detailVC animated:YES];
    detailVC = nil;
}

#pragma mark - UITableViewDataSource Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (self.listFilter.integerValue) {
        return [self.friends_dataArray count];
    }else{
        return[self.unlv_dataArray count];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:section];
    }
    return eventObj.k_eventRowCount_Home;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
       eventObj= [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj= [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    switch (indexPath.row) {
        case 0:
        {
            static NSString *eventDetailCell = @"eventDetailCell";
            GWEventDetailCell* cell = (GWEventDetailCell*)[tableView dequeueReusableCellWithIdentifier:eventDetailCell];
            if (cell == nil) {
                cell = [[[NSBundle mainBundle] loadNibNamed:@"GWEventDetailCell" owner:nil options:nil] objectAtIndex:0];
                cell.delegate = self;
                [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
            }
            
            [cell.cellImageView setImageWithURL:getPhotoURL(eventObj.eventCreatorPhoto) placeholderImage:nil];
            [cell.cellDescriptionLabel setText:eventObj.eventDetail];
            [cell.cellNameLabel setText:eventObj.eventCreatorName];
            [cell.cellRSVPButton setSelected:[eventObj.eventRSPVed boolValue]];
            [cell.cellRSVPButton setUserInteractionEnabled:![eventObj.eventRSPVed boolValue]];
            
            [cell.cellRSVPButton addTarget:self action:@selector(rsvpButtonTapped:withEvent:) forControlEvents:UIControlEventTouchUpInside];
            [cell.cellImageButton addTarget:self action:@selector(imageButtonTapped:withEvent:) forControlEvents:UIControlEventTouchUpInside];

            cell.cellIndexPath = indexPath;
            [cell setNeedsLayout];
            return cell;
        }
            
        default:{
            id objC = [eventObj.k_uiarray objectAtIndex:indexPath.row-1];
            GWBaseObj *baseobj = (GWBaseObj *)objC;
            
            switch (baseobj.type) {
                case GwObject_AllComment:
                {
                    static NSString *viewAllCell = @"viewAllCell";
                    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:viewAllCell];
                    if (cell == nil) {
                        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:viewAllCell];
                        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
                        [cell.textLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:12.0]];
                        [cell.textLabel setTextAlignment:NSTextAlignmentCenter];
                        [cell.textLabel setTextColor:[UIColor darkGrayColor]];
                    }
                    [cell.textLabel setText:[NSString stringWithFormat:@"View all %@ comments",eventObj.eventCommentCount]];
                    return cell;
                }

                case GWObject_Photo:
                {
                    static NSString *eventImageCell = @"eventImageCell";
                    GWEventImageCell* cell = (GWEventImageCell*)[tableView dequeueReusableCellWithIdentifier:eventImageCell];
                    if (cell == nil) {
                        cell = [[GWEventImageCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:eventImageCell];
                        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];

                    }
                    [cell setCarouselDelegate:self];
                    [cell setIndexPath:indexPath];
                    [cell setDataSource:eventObj.eventPhotoList];
                    [cell.cellDivider setHidden:!eventObj.eventCommentList.count];
                    return cell;
                }
                default:{
                    static NSString *eventCommentCell = @"eventCommentCell";
                    GWEventCommentCell* cell = (GWEventCommentCell*)[tableView dequeueReusableCellWithIdentifier:eventCommentCell];
                    if (cell == nil) {
                        cell = [[GWEventCommentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:eventCommentCell];
                        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
                    }
                    GWCommentObj *comment = (GWCommentObj*)objC;
                    [cell.cellImageButton addTarget:self action:@selector(commentButtonTapped:withEvent:) forControlEvents:UIControlEventTouchUpInside];
                    [cell setCellUserComment:comment.userComment];
                    [cell setCellUserName:comment.userName];
                    [cell setCellUserPhoto:comment.userPhoto];
                    [cell layoutFrames];
                    
                    return cell;
                }
            }
        }
    }
}

#pragma mark - UITableViewDelegate Methods

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 35.0;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 0.0;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectZero];
    [view setBackgroundColor:[UIColor clearColor]];
    return view;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:section];
    }
    
    CBAutoScrollLabel *leftLabel = nil;
    UILabel *rightLabel = nil;
    UIButton *headerButton = nil;
    
    static NSString *cellHeader = @"cellHeader";
    UIView *view  = [tableView dequeueReusableHeaderFooterViewWithIdentifier:cellHeader];
    if (view == nil) {
        view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 35.0)];
        [view setBackgroundColor:[[GWAppSettings sharedInstance] app_lightGreyColor]];

        rightLabel = [[UILabel alloc] initWithFrame:CGRectMake(view.frame.size.width-(eventObj.k_eventTimeWidth_Home+5), 0, eventObj.k_eventTimeWidth_Home, view.frame.size.height)];
        [rightLabel setTextColor:[[GWAppSettings sharedInstance] app_blueColor]];
        [rightLabel setBackgroundColor:[UIColor clearColor]];
        [rightLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0]];
        [rightLabel setTextAlignment:NSTextAlignmentRight];
        [view addSubview:rightLabel];

        leftLabel =   [[CBAutoScrollLabel alloc] initWithFrame:CGRectMake(10, 0, view.frame.size.width-(eventObj.k_eventTimeWidth_Home+23), view.frame.size.height)];
        [leftLabel setScrollDirection:CBAutoScrollDirectionLeft];
        [leftLabel observeApplicationNotifications];
        leftLabel.textAlignment = NSTextAlignmentLeft;
        [leftLabel setTextColor:[[GWAppSettings sharedInstance] app_blueColor]];
        [leftLabel setBackgroundColor:[UIColor clearColor]];
        [leftLabel setFont:[[GWAppSettings sharedInstance] app_HelveticaNeueMediumWithSize:16.0]];
        [view addSubview:leftLabel];
    
        headerButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [headerButton setFrame:view.frame];
        [view addSubview:headerButton];
    
    }
    [leftLabel setText:eventObj.eventName];
    [rightLabel setText:eventObj.eventTimeRemainString];
    [headerButton addTarget:self action:@selector(headerButtonTapped:withEvent:) forControlEvents:UIControlEventTouchUpInside];

    return view;
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
    
    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
    }
    
    GWBaseObj *baseobj;
    
    switch (indexPath.row) {
        case 0:{
            GWEventDetailVC *detailVC = [[GWEventDetailVC alloc] initWithNibName:@"GWEventDetailVC" bundle:nil];
            [detailVC setEventID:eventObj.eventID];
            [self.navigationController pushViewController:detailVC animated:YES];
            detailVC = nil;
        }
            break;
        case 1:{
            if ([eventObj.k_uiarray count]>0) {
                baseobj = [eventObj.k_uiarray objectAtIndex:indexPath.row-1];
            }
            if (baseobj.type == GwObject_AllComment) {
                GWCommentVC *commentVC = [[GWCommentVC alloc] initWithNibName:@"GWCommentVC" bundle:nil];
                [commentVC setEventID:eventObj.eventID];
                [self.navigationController pushViewController:commentVC animated:YES];
                commentVC = nil;
            }else if (baseobj.type == GwObject_Comment){
                GWCommentObj *comment = (GWCommentObj *)baseobj;
                if (!comment.userID) {
                    return;
                }
                if ([comment.userID isEqualToString:[kDef objectForKey:kUserID]]) {
                    GWMyProfileVC *profileVC = [[GWMyProfileVC alloc] initWithNibName:@"GWMyProfileVC" bundle:nil];
                    [profileVC setNotFromSlider:YES];
                    [self.navigationController pushViewController:profileVC animated:YES];
                    profileVC = nil;
                }else{
                    GWUserPrfoileVC *userVC = [[GWUserPrfoileVC alloc] initWithNibName:@"GWUserPrfoileVC" bundle:nil];
                    [userVC setUserID:comment.userID];
                    [self.navigationController pushViewController:userVC animated:YES];
                    userVC = nil;
                }
            }
        }
            break;
        default:{
            if ([eventObj.k_uiarray count]>0) {
                baseobj = [eventObj.k_uiarray objectAtIndex:indexPath.row-1];
            }
                if (baseobj.type == GwObject_Comment){
                GWCommentObj *comment = (GWCommentObj *)baseobj;
                if (!comment.userID) {
                    return;
                }
                if ([comment.userID isEqualToString:[kDef objectForKey:kUserID]]) {
                    GWMyProfileVC *profileVC = [[GWMyProfileVC alloc] initWithNibName:@"GWMyProfileVC" bundle:nil];
                    [profileVC setNotFromSlider:YES];
                    [self.navigationController pushViewController:profileVC animated:YES];
                    profileVC = nil;
                }else{
                    GWUserPrfoileVC *userVC = [[GWUserPrfoileVC alloc] initWithNibName:@"GWUserPrfoileVC" bundle:nil];
                    [userVC setUserID:comment.userID];
                    [self.navigationController pushViewController:userVC animated:YES];
                    userVC = nil;
                }
            }
        }
            break;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {

    GWEventObj *eventObj = nil;
    if (self.listFilter.integerValue) {
        eventObj = [self.friends_dataArray objectAtIndex:indexPath.section];
    }else{
        eventObj = [self.unlv_dataArray objectAtIndex:indexPath.section];
    }

    switch (indexPath.row) {
        case 0:
            return 140.0;
            
        default:{
            id Obj = nil;
            GWBaseObj *baseobj;
            
            if ([eventObj.k_uiarray count]>0) {
                Obj = [eventObj.k_uiarray objectAtIndex:indexPath.row-1];
            }
            baseobj = (GWBaseObj*)Obj;
            switch (baseobj.type) {
                case GWObject_Photo:
                    return 190.0;
                case GwObject_AllComment:
                    return 25.0;
                default:
                    return [(GWCommentObj*)Obj k_rowSize_Home];
            }
        }
    }
}

#pragma mark - UIScrollView delegate methods

- (void)scrollViewDidScroll: (UIScrollView *)scroll {
    
    
    NSInteger currentOffset = scroll.contentOffset.y;
    NSInteger maximumOffset = scroll.contentSize.height - scroll.frame.size.height;
    
    if (maximumOffset - currentOffset <= 10.0) {
        
        if (self.listFilter.integerValue) {
            if (!isMaxPage_friends && [self.friends_dataArray count] >= 10 && !isLoadMoreExecuting_friends) {
                pageNumber_friends = pageNumber_friends + 1;
                isLoadMoreExecuting_friends = YES;
                [self callGetEventFeedService_withHUD:NO andHUDText:@"Please Wait..."];
            }
        }
        else{
            if (!isMaxPage_unlv && [self.unlv_dataArray count] >= 10 && !isLoadMoreExecuting_unlv) {
                pageNumber_unlv = pageNumber_unlv + 1;
                isLoadMoreExecuting_unlv = YES;
                [self callGetEventFeedService_withHUD:NO andHUDText:@"Please Wait..."];
            }
        }
        
    }
}

#pragma mark - GWService Heleper  methods

- (NSDictionary *)getPageDetails {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:[NSString stringWithFormat:@"%d",((self.listFilter.integerValue)?pageNumber_friends:pageNumber_unlv)] forKey:@"pageNo"];
    [dict setObject:@"10" forKey:@"pageSize"];
    return dict;
}

- (void) updatePaginationValue:(GWPagination *)pagination {
    
    if (!self.listFilter.integerValue) {
        
        if (tempListFilter) {
            isMaxPage_friends = ([pagination.pageNo isEqualToString:pagination.maxPageNo]) ? YES:NO;
            pageNumber_friends = [pagination.pageNo integerValue];
            return;
        }
        
        isMaxPage_unlv = ([pagination.pageNo isEqualToString:pagination.maxPageNo]) ? YES:NO;
        pageNumber_unlv = [pagination.pageNo integerValue];
        
        (isMaxPage_unlv)?[self.homeTable setTableFooterView:[self endFooterView]]:[self.homeTable setTableFooterView:[self loadMoreFooterView]];

    }else{
        isMaxPage_friends = ([pagination.pageNo isEqualToString:pagination.maxPageNo]) ? YES:NO;
        pageNumber_friends = [pagination.pageNo integerValue];

        (isMaxPage_friends)?[self.homeTable setTableFooterView:[self endFooterView]]:[self.homeTable setTableFooterView:[self loadMoreFooterView]];
    }

    
}

-(void)callGetEventFeedService_withHUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[[UIApplication sharedApplication] delegate] window] withText:HUDText animated:YES dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper cancelRequestwithName:GWService_getEventFeed];
    [helper setServiceHelperDelegate:self];
    
    NSDictionary *requestDict = [[NSDictionary alloc] initWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",self.categoryFilter,@"categoryFilter",self.listFilter,@"listFilter",[self getPageDetails],@"pagination", nil];
    
    [helper callPOSTMethodWithData:requestDict andMethodName:GWService_getEventFeed];
}

-(void)callGetEventFeedService_forFriends{

    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper cancelRequestwithName:GWService_getEventFeed];
    [helper setServiceHelperDelegate:self];
    
    tempListFilter = YES;
    
    NSDictionary *requestDict = [[NSDictionary alloc] initWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",self.categoryFilter,@"categoryFilter",@"1",@"listFilter",[NSDictionary dictionaryWithObjectsAndKeys:@"1",@"pageNo",@"10",@"pageSize", nil],@"pagination", nil];
    
    [helper callPOSTMethodWithData:requestDict andMethodName:GWService_getEventFeed];
}

-(void)callGetEventDetailService_withHUD:(BOOL)showHUD andHUDText:(NSString*)HUDText andEventID:(NSString*)eventID{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:YES dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",eventID,@"eventID", nil] andMethodName:GWService_getEventDetail];
}


-(void)callUploadPhotoWithImage:(UIImage*)image andEventID:(NSString*)eventID withHUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:YES dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",eventID,@"eventID",image,@"image",@"0",@"photoType",[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]],@"photoTime", nil] andMethodName:GWService_uploadPhoto];
}

-(void)callCommentOnEventService_withComment:(NSString*)comment andEventID:(NSString*)eventID HUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:YES dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",eventID,@"eventID",@"0",@"commentType",[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]],@"time",comment,@"comment", nil] andMethodName:GWService_addComment];
}

-(void)callRSVPService_withPostOnProfile:(NSString*)shouldPost andEventID:(NSString*)eventID HUD:(BOOL)showHUD andHUDText:(NSString*)HUDText{
    
    if (showHUD) {
        [MBProgressHUD showHUDAddedTo:[[UIApplication sharedApplication] keyWindow] withText:HUDText animated:YES dimBackground:YES];
    }
    
    GWServiceHelper *helper = [GWServiceHelper sharedHelper];
    [helper setServiceHelperDelegate:self];
    
    [helper callPOSTMethodWithData:[NSDictionary dictionaryWithObjectsAndKeys:[kDef objectForKey:kUserID],@"userID",eventID,@"eventID",shouldPost,@"postOnProfile", nil]andMethodName:GWService_RSVPEvent];
}

#pragma mark - GWService Heleper Delegte methods
-(void)serviceResponse:(id)response andMethodName:(GWServiceMethod)methodName{
    [MBProgressHUD hideAllHUDsForView:[[[UIApplication sharedApplication] delegate] window] animated:YES];
    
    switch (methodName) {
        case GWService_getEventFeed:
        {
            if (tempListFilter) {
                isLoadMoreExecuting_friends = NO;
                if (pageNumber_friends == 1) {
                    [self.friends_dataArray removeAllObjects];
                }
                GWPagination *pagination = [GWPagination paginationFromDict:[response objectForKey:@"pagination"]];
                [self updatePaginationValue:pagination];
                tempListFilter = NO;

                for (NSDictionary* dict in [response objectForKey:@"eventList"]) {
                    GWEventObj *eventObj = [GWEventObj eventFromDict:dict];
                    [self.friends_dataArray addObject:eventObj];
                }
                if ([(UIButton *)[self.view viewWithTag:303] isSelected]) {
                    [self.noDataLabel setHidden:self.friends_dataArray.count];
                    [self.homeTable reloadData];
                }

            }
            else if (self.listFilter.integerValue) {
                isLoadMoreExecuting_friends = NO;
                if (pageNumber_friends == 1) {
                    [self.friends_dataArray removeAllObjects];
                }
                GWPagination *pagination = [GWPagination paginationFromDict:[response objectForKey:@"pagination"]];
                [self updatePaginationValue:pagination];
                
                for (NSDictionary* dict in [response objectForKey:@"eventList"]) {
                    GWEventObj *eventObj = [GWEventObj eventFromDict:dict];
                    [self.friends_dataArray addObject:eventObj];
                }
                
                [self.noDataLabel setHidden:self.friends_dataArray.count];
                [self.homeTable reloadData];
                if (pageNumber_friends == 1) {
                    [self.refreshControl endRefreshing];
                    [self.refreshControl setAttributedTitle:nil];
                }
            }else{
                isLoadMoreExecuting_unlv = NO;
                if (pageNumber_unlv == 1) {
                    [self.unlv_dataArray removeAllObjects];
                }
                GWPagination *pagination = [GWPagination paginationFromDict:[response objectForKey:@"pagination"]];
                [self updatePaginationValue:pagination];
                
                for (NSDictionary* dict in [response objectForKey:@"eventList"]) {
                    GWEventObj *eventObj = [GWEventObj eventFromDict:dict];
                    [self.unlv_dataArray addObject:eventObj];
                }
                
                [self.noDataLabel setHidden:self.unlv_dataArray.count];
                [self.homeTable reloadData];
                if (pageNumber_unlv == 1) {
                    if (![self.friends_dataArray count]) {
                        [self callGetEventFeedService_forFriends];
                    }
                    
                    [self.refreshControl endRefreshing];
                    [self.refreshControl setAttributedTitle:nil];
                }
            }
        }
            break;
            
        case GWService_addComment:{
            [self callGetEventDetailService_withHUD:NO andHUDText:nil andEventID:selectedEvent.eventID];

        }
            break;
            
        case GWService_RSVPEvent:{
            [self callGetEventDetailService_withHUD:NO andHUDText:nil andEventID:selectedEvent.eventID];
        }
            break;
            
        case GWService_uploadPhoto:{
            [self callGetEventDetailService_withHUD:NO andHUDText:nil andEventID:selectedEvent.eventID];
        }
            break;
        case GWService_getEventDetail:{
            GWEventObj *eventObj = [GWEventObj eventFromDict:[response objectForKey:@"eventDetail"]];
            if ([self.unlv_dataArray containsObject:eventObj]) {
                [self.unlv_dataArray replaceObjectAtIndex:[self.unlv_dataArray indexOfObject:eventObj] withObject:eventObj];
            }
            if ([self.friends_dataArray containsObject:eventObj]) {
                [self.friends_dataArray replaceObjectAtIndex:[self.friends_dataArray indexOfObject:eventObj] withObject:eventObj];
            }
            [self.homeTable reloadData];

        }
            break;
        default:
            break;
    }
}

-(void)connectionFailWithError:(NSString *)error andMethodName:(GWServiceMethod)methodName{
    [MBProgressHUD hideAllHUDsForView:[[[UIApplication sharedApplication] delegate] window] animated:YES];

    if (methodName == GWService_getEventFeed) {
        
        if ([error isEqualToString:kNetworkErrorMessage]) {
            [self.refreshControl setAttributedTitle:[[NSAttributedString alloc] initWithString:@"Check your connection and try again" attributes:[NSDictionary dictionaryWithObjectsAndKeys:[[GWAppSettings sharedInstance] app_darkGreyColor],NSForegroundColorAttributeName,[UIFont fontWithName:@"Helvetica-Regilar" size:12.0],NSFontAttributeName, nil]]];
            [self.refreshControl performSelector:@selector(endRefreshing) withObject:nil afterDelay:0.5];
            
        }else{
            [self.refreshControl endRefreshing];
            [self.refreshControl setAttributedTitle:nil];
            [GWUtility showaAlertWithTitle:@"Error!" andMessage:error andSubtitle:nil andButtonAction:^(int tag, SIAlertViewButtonType type, BOOL subtitleSelected) {
                
            } andCancelButton:nil andOtherButtons:@"OK"];

        }
        
        if (self.listFilter.integerValue) {
            isMaxPage_friends = 1;
            [self.noDataLabel setHidden:self.friends_dataArray.count];
        }else{
            [self.noDataLabel setHidden:self.unlv_dataArray.count];
            isMaxPage_unlv = 1;
        }
        
        [self.homeTable setTableFooterView:[self endFooterView]];

    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)dealloc{
    self.unlv_dataArray = nil;
    self.friends_dataArray = nil;
    self.refreshControl = nil;
    
    self.homeTable.delegate = nil;
    self.homeTable.dataSource = nil;
    self.homeTable = nil;
}

@end
