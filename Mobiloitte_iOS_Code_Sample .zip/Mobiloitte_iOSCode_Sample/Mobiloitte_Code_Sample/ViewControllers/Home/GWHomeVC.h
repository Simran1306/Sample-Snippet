//
//  GWHomeVC.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/13/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWHomeVC : GAITrackedViewController<eventDetailDelegate>

@property (nonatomic, strong) IBOutlet UITableView *homeTable;

@property (nonatomic, strong) NSMutableArray *unlv_dataArray;

@property (nonatomic, strong) NSMutableArray *friends_dataArray;

@property (nonatomic, strong) IBOutlet GWChat *commentField;

@property (nonatomic, strong) IBOutlet UILabel *noDataLabel;

@property (nonatomic, assign) BOOL shouldUpdate;

@property (nonatomic, strong) UIRefreshControl *refreshControl;

@property (nonatomic, strong) NSString *categoryFilter;
@property (nonatomic, strong) NSString *listFilter;

-(IBAction)commonButtionAction:(id)sender;

-(IBAction)centerButtionAction:(id)sender;


@end
 