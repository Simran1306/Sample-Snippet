//
//  GWEventDetailCell.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWEventDetailCell.h"

@implementation GWEventDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

-(void)layoutSubviews{
    [super layoutSubviews];
    [self.cellDescriptionLabel sizeToFit];
//    [self.cellNameLabel sizeToFit];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self initGWMenu];
}


-(void)initGWMenu{

    GWMenuItem *starMenuItem2 = [[GWMenuItem alloc] initWithImage:[UIImage imageNamed:@"comment_btn.png"]
                                                           highlightedImage:nil
                                                               ContentImage:nil
                                                    highlightedContentImage:nil];
    GWMenuItem *starMenuItem3 = [[GWMenuItem alloc] initWithImage:[UIImage imageNamed:@"camera_btn.png"]
                                                           highlightedImage:nil
                                                               ContentImage:nil
                                                    highlightedContentImage:nil];
    GWMenuItem *starMenuItem4 = [[GWMenuItem alloc] initWithImage:[UIImage imageNamed:@"share_btn.png"]
                                                           highlightedImage:nil
                                                               ContentImage:nil
                                                    highlightedContentImage:nil];

    
    GWMenu *menu = [[GWMenu alloc] initWithFrame:self.bounds menus:[NSArray arrayWithObjects:starMenuItem2,starMenuItem3,starMenuItem4, nil]];
    UIImage *GWMenuImage = [UIImage imageNamed:@"bullet_btn.png"];
    UIImage *GWMenuImagePressed = [UIImage imageNamed:@"bullet_btn.png"];
    [menu setHighlightedImage:GWMenuImagePressed];
    [menu setContentImage:GWMenuImage];
    [menu setHighlightedContentImage:GWMenuImagePressed];
    
    menu.delegate = self;
    menu.startPoint = self.cellAccessotyButton.center;
    
    menu.menuWholeAngle = M_PI/180*270 ;
    menu.rotateAngle = M_PI/180 *180 ;
    
 
    [self addSubview:menu];
    [self bringSubviewToFront:menu];
}

- (void)GWMenu:(GWMenu *)menu didSelectIndex:(NSInteger)idx{
    [menu performSelector:@selector(hideItems) withObject:nil afterDelay:0.3f];
   

    if ([self.delegate respondsToSelector:@selector(MenuBottonTappedWithIndex:andButtonIndex:)]) {
        [self.delegate MenuBottonTappedWithIndex:self.cellIndexPath andButtonIndex:idx];
    }
}

- (void)GWMenuDidFinishAnimationClose:(GWMenu *)menu{
    [menu hideItems];
}
- (void)GWMenuDidFinishAnimationOpen:(GWMenu *)menu{
    
}

@end
