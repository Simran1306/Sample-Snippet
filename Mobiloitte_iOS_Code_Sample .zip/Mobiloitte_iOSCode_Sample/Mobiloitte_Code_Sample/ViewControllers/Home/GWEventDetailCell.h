//
//  GWEventDetailCell.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/22/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWMenu.h"

@protocol eventDetailDelegate;


@interface GWEventDetailCell : UITableViewCell<GWMenuDelegate>

@property (nonatomic, strong) IBOutlet UIImageView *cellImageView;

@property (nonatomic, strong) IBOutlet UIButton *cellImageButton;

@property (nonatomic, strong) IBOutlet UILabel *cellNameLabel;

@property (nonatomic, strong) IBOutlet UILabel *cellDescriptionLabel;

@property (nonatomic, strong) IBOutlet UIButton *cellRSVPButton;

@property (nonatomic, strong) IBOutlet UIButton *cellAccessotyButton;

//@property (nonatomic, strong) IBOutlet UIButton *cellAttendeeButton;

@property (nonatomic, strong) NSIndexPath *cellIndexPath;


@property (nonatomic, assign) id<eventDetailDelegate> delegate;

@end

@protocol eventDetailDelegate <NSObject>

- (void)MenuBottonTappedWithIndex:(NSIndexPath*)index andButtonIndex:(NSInteger)idx;

@end