//
//  GWPhotoObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWPhotoObj : GWBaseObj

@property (nonatomic, strong) NSString *photoID;
@property (nonatomic, strong) NSString *photoURL;

@property (nonatomic, strong) NSString *photoLikeCount;
@property (nonatomic, strong) NSString *phototaggedPeople;
@property (nonatomic, strong) NSMutableArray *phototaggedPeople_array;

@property (nonatomic, strong) NSString *photoIsLikedByMe;
@property (nonatomic, strong) NSString *photoCommentCount;
@property (nonatomic, strong) NSString *photoTimeString;
@property (nonatomic, strong) NSString *photoTimeString_UI;
@property (nonatomic, strong) NSString *photoTypeName;

@property (nonatomic, strong) NSMutableArray *photoCommentList;

+(GWPhotoObj*)photoFromDict:(NSDictionary*)dict;


@property (nonatomic, strong, readonly) NSMutableArray *k_uiarray_detail;
@property (nonatomic, readonly) CGFloat k_rowSize_Tag;
@property (nonatomic, readonly) NSInteger k_rowCount_detail;


@end
