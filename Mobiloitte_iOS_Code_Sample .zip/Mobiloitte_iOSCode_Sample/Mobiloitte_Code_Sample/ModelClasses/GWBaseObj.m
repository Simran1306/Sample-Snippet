//
//  GWBaseObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/27/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWBaseObj.h"

@implementation GWBaseObj

@end
