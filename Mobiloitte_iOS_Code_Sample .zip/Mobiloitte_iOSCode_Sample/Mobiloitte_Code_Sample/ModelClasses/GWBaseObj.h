//
//  GWBaseObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/27/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef  enum _GWObjectType {
    GWObject_Event = 0,
    GwObject_Comment,
    GwObject_AllComment,
    GWObject_Photo,
    GWObject_Like,
    GWObject_Tag,
    GWObject_notification
} GWObjectType;


@interface GWBaseObj : NSObject

@property (nonatomic, assign) GWObjectType type;


@end
