//
//  GWPagination.h
//  Demo!
//
//  Created by Apoorve Tyagi on 10/1/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWPagination : NSObject

@property (nonatomic, strong) NSString *pageSize;
@property (nonatomic, strong) NSString *pageNo;
@property (nonatomic, strong) NSString *totalNoRecords;
@property (nonatomic, strong) NSString *maxPageNo;

+(GWPagination*)paginationFromDict:(NSDictionary*)dict;

@end
