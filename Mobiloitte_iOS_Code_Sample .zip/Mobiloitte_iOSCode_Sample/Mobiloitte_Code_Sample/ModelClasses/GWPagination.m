//
//  GWPagination.m
//  Demo!
//
//  Created by Apoorve Tyagi on 10/1/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWPagination.h"

@implementation GWPagination

+(GWPagination*)paginationFromDict:(NSDictionary*)dict{
    GWPagination *pagination = [[GWPagination alloc] init];
    [pagination setPageNo:[dict objectForKeyNotNull:@"pageNo" expectedObj:@"1"]];
    [pagination setPageSize:[dict objectForKeyNotNull:@"pageSize" expectedObj:@"10"]];
    [pagination setTotalNoRecords:[dict objectForKeyNotNull:@"totalNoRecords" expectedObj:@"0"]];
    [pagination setMaxPageNo:[dict objectForKeyNotNull:@"maxPageNo" expectedObj:@"1"]];
    
    return pagination;
}

@end
