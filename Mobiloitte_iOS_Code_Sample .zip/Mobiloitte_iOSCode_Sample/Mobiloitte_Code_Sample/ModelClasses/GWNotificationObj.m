//
//  GWNotificationObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/9/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWNotificationObj.h"

@implementation GWNotificationObj

+(GWNotificationObj*)notificationFromDict:(NSDictionary*)dict {
    
    GWNotificationObj *notificationObj = [[GWNotificationObj alloc] init];
    
    [notificationObj setUserID:[dict objectForKeyNotNull:@"userID" expectedObj:@""]];
    [notificationObj setUserPhoto:[dict objectForKeyNotNull:@"userProfilePhoto" expectedObj:@""]];
    [notificationObj setUserFName:[dict objectForKeyNotNull:@"firstname" expectedObj:@""]];
    [notificationObj setUserLName:[dict objectForKeyNotNull:@"lastname" expectedObj:@""]];
    [notificationObj setUserName:[NSString stringWithFormat:@"%@ %@",notificationObj.userFName,notificationObj.userLName]];
    
    [notificationObj setNotificationText:[dict objectForKeyNotNull:@"notifMessage" expectedObj:@""]];
    [notificationObj setNotificationType:[[dict objectForKeyNotNull:@"notificationType" expectedObj:@"0"] integerValue]];
    
    [notificationObj setEventID:[dict objectForKeyNotNull:@"eventID" expectedObj:@""]];
    [notificationObj setPhotoID:[dict objectForKeyNotNull:@"photoID" expectedObj:@""]];

    return notificationObj;
}

@end
