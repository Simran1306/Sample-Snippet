//
//  GWGroupObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/30/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"
@interface GWGroupObj : NSObject

@property (nonatomic, strong) NSString *groupID;
@property (nonatomic, strong) NSString *groupName;
@property (nonatomic, strong) NSString *groupMemberCount;
@property (nonatomic, strong) NSString *groupMemberCount_Text;

@property (nonatomic, strong) NSMutableArray *groupMemberList;

@property (nonatomic, strong) NSString *isSelected;


+(GWGroupObj*)groupFromDict:(NSDictionary*)dict;

@end
