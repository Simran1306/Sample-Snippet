//
//  GWGroupObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/30/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWGroupObj.h"

@implementation GWGroupObj

+(GWGroupObj*)groupFromDict:(NSDictionary*)dict{
    GWGroupObj *group = [[GWGroupObj alloc] init];
    [group setGroupID:[dict objectForKeyNotNull:@"groupID" expectedObj:@""]];
    [group setGroupName:[dict objectForKeyNotNull:@"groupName" expectedObj:@""]];
    [group setGroupMemberCount:[dict objectForKeyNotNull:@"memberCount" expectedObj:@"0"]];
    [group setGroupMemberCount_Text:[NSString stringWithFormat:@"%@ members",group.groupMemberCount]];
    group.groupMemberList = [[NSMutableArray alloc] init];
    
    for (NSDictionary *friendDict in [dict objectForKeyNotNull:@"memberList" expectedObj:[NSArray array]]) {
        GWFriendObj *frnd = [GWFriendObj friendFromDict:friendDict];
        [group.groupMemberList addObject:frnd];
    }
    
    return group;
    
}


@end
