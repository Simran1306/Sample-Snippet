//
//  GWCommentObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWCommentObj.h"

@interface GWCommentObj()

@property (nonatomic, readwrite) CGFloat k_rowSize_Home;
@property (nonatomic, readwrite) CGFloat k_rowSize_Comment;

@end

@implementation GWCommentObj

+(GWCommentObj*)commentFromDict:(NSDictionary*)dict{

    GWCommentObj *commentObj = [[GWCommentObj alloc] init];
    [commentObj setType:GwObject_Comment];
    
    [commentObj setUserComment:[dict objectForKeyNotNull:@"userComment" expectedObj:@""]];
    [commentObj setUserID:[dict objectForKeyNotNull:@"userID" expectedObj:@""]];
    
    [commentObj setUserFName:[dict objectForKeyNotNull:@"firstname" expectedObj:@""]];
    [commentObj setUserLName:[dict objectForKeyNotNull:@"lastname" expectedObj:@""]];
    [commentObj setUserName:[NSString stringWithFormat:@"%@ %@",commentObj.userFName,commentObj.userLName]];
    
    [commentObj setUserPhoto:[dict objectForKeyNotNull:@"userPhoto" expectedObj:@""]];
    [commentObj setCommentTime:[dict objectForKeyNotNull:@"time" expectedObj:kDefaultTime]];
    [commentObj setCommentTime_UI:[commentObj getCommenttime_UI:commentObj.commentTime]];
    
    NSString *concatStr = [NSString stringWithFormat:@"%@ : %@",commentObj.userName,commentObj.userComment];
    CGSize sizeHome = [concatStr sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:13.0] constrainedToSize:CGSizeMake(240, MAXFLOAT)];
    commentObj.k_rowSize_Home = MAX(42, sizeHome.height+5);

    CGSize sizeComment = [commentObj.userComment sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:13.0] constrainedToSize:CGSizeMake(260, MAXFLOAT)];
    commentObj.k_rowSize_Comment = MAX(55, sizeComment.height+34);
    
    return commentObj;
}

-(NSString*)getCommenttime_UI:(NSString*)timeStampString{
    NSString *_timeElapsed = nil;
    
    NSTimeInterval noOfSec = [[NSDate dateWithTimeIntervalSince1970:timeStampString.doubleValue] timeIntervalSinceNow];
    int sec = abs(noOfSec);
    int days = abs(noOfSec / (60 * 60 * 24));
    int hours = abs(noOfSec / (60 * 60));
    int minutes = abs(noOfSec / 60);
    int weeks = days/7;
    
    if (weeks == 0) {
        if (days == 0) {
            if (hours == 0) {
                if (minutes == 0) {
                    _timeElapsed = [NSString stringWithFormat:@"%d s",sec];
                }
                else{
                    _timeElapsed = [NSString stringWithFormat:@"%d m",minutes];
                }
            }
            else{
                _timeElapsed = [NSString stringWithFormat:@"%d h",hours];
            }
        }
        else{
            _timeElapsed = [NSString stringWithFormat:@"%d d",days];
        }
    }
    else{
        _timeElapsed = [NSString stringWithFormat:@"%d w",weeks];
    }
    
    return _timeElapsed;
}

@end
