//
//  GWUser.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/2/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWUserObj : GWBaseObj

@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *userEmail;
@property (nonatomic, strong) NSString *userName;

@property (nonatomic, strong) NSString *userFName;
@property (nonatomic, strong) NSString *userLName;

@property (nonatomic, strong) NSString *userGender;
@property (nonatomic, strong) NSString *userPhoneNo;
@property (nonatomic, strong) UIImage *userProfilePhoto;

@property (nonatomic, strong) NSString *userFriendCount;
@property (nonatomic, strong) NSString *userMutualFriendCount;
@property (nonatomic, strong) NSString *isMyFriend;
@property (nonatomic, strong) NSString *userBio;
@property (nonatomic, strong) NSString *userProfilePhotoURL;

@property (nonatomic, strong) NSMutableArray *userPhotos;
@property (nonatomic, strong) NSMutableArray *upcomingEvents;
@property (nonatomic, strong) NSMutableArray *taggedPhotos;

+(GWUserObj*)userFromDict:(NSDictionary*)dict;

+(GWUserObj*)userFromDict:(NSDictionary*)dict andPreviousObj:(GWUserObj*)prevObj;


-(NSDictionary*)dictForCompleteProfileFromUserObj:(GWUserObj*)userObj;


// properties for UI formatting
@property (nonatomic, readonly) CGFloat k_userBioHeight;

@end
