//
//  GWPhotoObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWPhotoObj.h"

@interface GWPhotoObj()

@property (nonatomic, strong, readwrite) NSMutableArray *k_uiarray_detail;
@property (nonatomic, readwrite) CGFloat k_rowSize_Tag;
@property (nonatomic, readwrite) NSInteger k_rowCount_detail;

@end

@implementation GWPhotoObj

+(GWPhotoObj*)photoFromDict:(NSDictionary*)dict{
    GWPhotoObj *photoObj = [[GWPhotoObj alloc] init];
    [photoObj setType:GWObject_Photo];
    
    [photoObj setPhotoID:[dict objectForKeyNotNull:@"photoID" expectedObj:@""]];
    [photoObj setPhotoURL:[dict objectForKeyNotNull:@"photoURL" expectedObj:@""]];
    [photoObj setPhotoTypeName:[dict objectForKeyNotNull:@"photoTypeName" expectedObj:@""]];

    [photoObj setPhotoLikeCount:[dict objectForKeyNotNull:@"likeCount" expectedObj:@"0"]];
    
    photoObj.phototaggedPeople_array = [[NSMutableArray alloc] init];
    
    for (NSDictionary *dicttionary in [dict objectForKeyNotNull:@"taggedPeople" expectedObj:[NSArray array]]) {
        GWUserObj *user = [GWUserObj userFromDict:dicttionary];
        [photoObj.phototaggedPeople_array addObject:user];
    }
    
    [photoObj setPhototaggedPeople:[photoObj getTaggedPeopleList:photoObj.phototaggedPeople_array]];
    [photoObj setPhotoIsLikedByMe:[dict objectForKeyNotNull:@"isLikedByMe" expectedObj:@"0"]];
    [photoObj setPhotoCommentCount:[dict objectForKeyNotNull:@"commentCount" expectedObj:@"0"]];
    [photoObj setPhotoTimeString:[dict objectForKeyNotNull:@"photoTime" expectedObj:kDefaultTime]];
    [photoObj setPhotoTimeString_UI:convertToString([NSDate dateWithTimeIntervalSince1970:[photoObj.photoTimeString floatValue]], @"MMMM dd 'at' hh:mm a")];

    photoObj.photoCommentList = [[NSMutableArray alloc] init];
    
    if ([[dict objectForKeyNotNull:@"commentList" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict2 in [dict objectForKeyNotNull:@"commentList" expectedObj:[NSArray array]]) {
            GWCommentObj *comment = [GWCommentObj commentFromDict:dict2];
            [photoObj.photoCommentList addObject:comment];
           
        }
    }
    photoObj.k_uiarray_detail = [photoObj getUIArray:photoObj];
    CGSize sizeDetail = [photoObj.phototaggedPeople sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0] constrainedToSize:CGSizeMake(265, MAXFLOAT)];

    photoObj.k_rowSize_Tag = MAX(sizeDetail.height+10, 30);
    photoObj.k_rowCount_detail = 1 + (([[photoObj photoLikeCount] integerValue]>0)?1:0) + (([[photoObj phototaggedPeople] length]>0)?1:0) + (MIN([photoObj.photoCommentCount integerValue], 4));
    return photoObj;
}

/**
 **Returns an array with objects in order that are appearing on home feed screen
 **/

-(NSMutableArray*)getUIArray:(GWPhotoObj*)photoObjct{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    if ([[photoObjct photoLikeCount] integerValue]>0) {
        GWBaseObj *base = [[GWBaseObj alloc] init];
        [base setType:GWObject_Like];
        [array addObject:base];
    }
    
    
    if ([[photoObjct phototaggedPeople_array] count]>0) {
        GWBaseObj *base = [[GWBaseObj alloc] init];
        [base setType:GWObject_Tag];
        [array addObject:base];
    }
    
    if ([[photoObjct photoCommentCount] integerValue]>3) {
        GWBaseObj *base = [[GWBaseObj alloc] init];
        [base setType:GwObject_AllComment];
        [array addObject:base];
    }
    int count = 0;
    for (GWCommentObj *obj in photoObjct.photoCommentList) {
        if (count>3) {
            break;
        }
        [array addObject:obj];
        count++;
    }

    return array;
}

-(NSString*)getTaggedPeopleList:(NSMutableArray*)array{
    NSMutableString *str = [[NSMutableString alloc] init];
    NSString *returnString;
    for (GWUserObj *user in array) {
        [str appendFormat:@"%@, ",user.userName];
    }
    if (str.length) {
        returnString = [str substringToIndex:[str length]-2];
    }
    
    return returnString;
}


- (BOOL)isEqual:(GWPhotoObj*)anObject
{
    if([self.photoID isEqualToString:anObject.photoID])
        return YES;
    
    return NO;
}

- (NSUInteger)hash
{
    return [self.photoID hash]; //Must be a unique unsinged integer
}


@end

