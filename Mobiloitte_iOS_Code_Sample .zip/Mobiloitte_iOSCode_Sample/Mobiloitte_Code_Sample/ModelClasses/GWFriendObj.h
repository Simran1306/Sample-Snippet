//
//  GWFriendObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/17/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWFriendObj : NSObject

@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *userName;

@property (nonatomic, strong) NSString *userFName;
@property (nonatomic, strong) NSString *userLName;

@property (nonatomic, strong) NSString *userPhotoURL;
@property (nonatomic, strong) NSString *userPhoneNo;
@property (nonatomic, strong) NSString *mutualFriendCount;
@property (nonatomic, strong) NSString *mutualFriendCount_Text;

@property (nonatomic, strong) NSString *isMyFriend;

@property (nonatomic, strong) NSString *isSelected;


+(GWFriendObj*)friendFromDict:(NSDictionary*)dict;

@end
