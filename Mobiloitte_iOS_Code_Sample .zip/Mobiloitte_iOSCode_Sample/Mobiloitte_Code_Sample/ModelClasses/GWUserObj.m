//
//  GWUser.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/2/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWUserObj.h"

@interface GWUserObj()

@property (nonatomic, readwrite) CGFloat k_userBioHeight;


@end

@implementation GWUserObj

+(GWUserObj*)userFromDict:(NSDictionary*)dict{
    GWUserObj *user = [[GWUserObj alloc] init];
    [user setUserFName:[dict objectForKeyNotNull:@"firstname" expectedObj:@""]];
    [user setUserLName:[dict objectForKeyNotNull:@"lastname" expectedObj:@""]];
    [user setUserName:[NSString stringWithFormat:@"%@ %@",user.userFName,user.userLName]];
    
    [user setUserID:[dict objectForKeyNotNull:@"userID" expectedObj:@""]];
    [user setUserFriendCount:[NSString stringWithFormat:@"%@ Friends",[dict objectForKeyNotNull:@"userFriendCount" expectedObj:@"0"]]];
    [user setUserMutualFriendCount:[NSString stringWithFormat:@"%@ Mutual",[dict objectForKeyNotNull:@"mutualFriendCount" expectedObj:@"0"]]];
    [user setIsMyFriend:[dict objectForKeyNotNull:@"isMyFriend" expectedObj:@"0"]];
    [user setUserBio:[dict objectForKeyNotNull:@"userBio" expectedObj:@""]];
    [user setUserProfilePhotoURL:[dict objectForKeyNotNull:@"userProfilePhoto" expectedObj:@""]];
    [user setUserPhoneNo:[dict objectForKeyNotNull:@"mobileNumber" expectedObj:@""]];
    [user setUserEmail:[dict objectForKeyNotNull:@"emailID" expectedObj:@""]];

    
    user.upcomingEvents = [[NSMutableArray alloc] init];
    user.userPhotos = [[NSMutableArray alloc] init];
    user.taggedPhotos = [[NSMutableArray alloc] init];
    
    if ([[dict objectForKeyNotNull:@"upcomingEvents" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict2 in [dict objectForKeyNotNull:@"upcomingEvents" expectedObj:[NSArray array]]) {
            GWEventObj *event = [GWEventObj eventFromDict:dict2];
            [user.upcomingEvents addObject:event];
        }
    }
    
    if ([[dict objectForKeyNotNull:@"userPhotos" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict2 in [dict objectForKeyNotNull:@"userPhotos" expectedObj:[NSArray array]]) {
            GWPhotoObj *photo = [GWPhotoObj photoFromDict:dict2];
            [user.userPhotos addObject:photo];
        }
    }
    
    if ([[dict objectForKeyNotNull:@"taggedPhotos" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict2 in [dict objectForKeyNotNull:@"taggedPhotos" expectedObj:[NSArray array]]) {
            GWPhotoObj *photo = [GWPhotoObj photoFromDict:dict2];
            [user.taggedPhotos addObject:photo];
        }
    }
    
    CGSize sizeDetail = [user.userBio sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0] constrainedToSize:CGSizeMake(300.0, MAXFLOAT)];
    user.k_userBioHeight = sizeDetail.height+8;
    
    return user;
}

+(GWUserObj*)userFromDict:(NSDictionary*)dict andPreviousObj:(GWUserObj*)prevObj{
    if ([[dict objectForKeyNotNull:@"upcomingEvents" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary *dict2 in [dict objectForKeyNotNull:@"upcomingEvents" expectedObj:[NSArray array]]) {
            GWEventObj *event = [GWEventObj eventFromDict:dict2];
            [prevObj.upcomingEvents addObject:event];
        }
    }
    return prevObj;
}



-(NSDictionary*)dictForCompleteProfileFromUserObj:(GWUserObj*)userObj{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:userObj.userFName forKey:@"firstName"];
    [dict setObject:userObj.userLName forKey:@"lastName"];
    [dict setObject:userObj.userID forKey:@"userID"];
    [dict setObject:userObj.userGender forKey:@"Gender"];
    [dict setObject:userObj.userProfilePhoto forKey:@"image"];
    [dict setObject:[NSString stringWithFormat:@"%f",[[NSDate date] timeIntervalSince1970]] forKey:@"photoTime"];
    
    return dict;
}

// deprecated
-(NSMutableArray*)getSortedEventArray:(NSMutableArray*)array{
    NSMutableArray *sortedArray = [[NSMutableArray alloc] init];
    NSMutableArray *pastArray = [[NSMutableArray alloc] init];
    NSMutableArray *futureArray = [[NSMutableArray alloc] init];
    
    for (GWEventObj *event in array) {
         NSTimeInterval noOfSec = [[NSDate dateWithTimeIntervalSince1970:event.eventTimeString.doubleValue] timeIntervalSinceNow];
        if (noOfSec >= 0) {
            [futureArray addObject:event];
        }else{
            [pastArray addObject:event];
        }
    }
    
    [futureArray sortUsingComparator:^NSComparisonResult(GWEventObj* obj1, GWEventObj* obj2) {
        if ([obj1.eventTimeString floatValue] > [obj2.eventTimeString floatValue])
            return NSOrderedDescending;
        else if ([obj1.eventTimeString floatValue] < [obj2.eventTimeString floatValue])
            return NSOrderedAscending;
        return NSOrderedSame;
    }];
    
    [pastArray sortUsingComparator:^NSComparisonResult(GWEventObj* obj1, GWEventObj* obj2) {
        if ([obj1.eventTimeString floatValue] > [obj2.eventTimeString floatValue])
            return NSOrderedAscending;
        else if ([obj1.eventTimeString floatValue] < [obj2.eventTimeString floatValue])
            return NSOrderedDescending;
        return NSOrderedSame;
    }];
    
    [sortedArray addObjectsFromArray:futureArray];
    [sortedArray addObjectsFromArray:pastArray];
    return sortedArray;
}

@end
