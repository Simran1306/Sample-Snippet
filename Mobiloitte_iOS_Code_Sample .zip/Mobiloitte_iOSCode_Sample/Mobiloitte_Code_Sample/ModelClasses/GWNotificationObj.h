//
//  GWNotificationObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 9/9/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

typedef  enum _GWNotificationType {
    GWNotification_invite = 0,
    GWNotification_like,
    GWNotification_commentPhoto,
    GWNotification_commentEvent,
    GWNotification_tag,
    
} GWNotificationType;

@interface GWNotificationObj : GWBaseObj

@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *notificationID;
@property (nonatomic, strong) NSString *userName;

@property (nonatomic, strong) NSString *userFName;
@property (nonatomic, strong) NSString *userLName;

@property (nonatomic, strong) NSString *userPhoto;
@property (nonatomic, strong) NSString *notificationText;

@property (nonatomic, strong) NSString *eventID;
@property (nonatomic, strong) NSString *photoID;

@property (nonatomic, assign) GWNotificationType notificationType;

+(GWNotificationObj*)notificationFromDict:(NSDictionary*)dict;

@end
