//
//  GWEventObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWEventObj.h"

@interface GWEventObj()

@property (nonatomic, readwrite) NSInteger k_eventRowCount_Home;
@property (nonatomic, readwrite) NSString *k_eventAttendeeTotal;
@property (nonatomic, strong, readwrite) NSMutableArray *k_uiarray;
@property (nonatomic, assign, readwrite) CGFloat k_rowMinHeight_EventDetail;
@property (nonatomic, assign, readwrite) CGFloat k_rowFullHeight_EventDetail;
@property (nonatomic, assign, readwrite) CGFloat k_eventTimeWidth_Home;
@property (nonatomic, assign, readwrite) CGFloat k_rowHeight_EventName;

@end

@implementation GWEventObj

+(GWEventObj*)eventFromDict:(NSDictionary*)dict{

    GWEventObj *eventObj = [[GWEventObj alloc] init];
    [eventObj setType:GWObject_Event];
    
    
    [eventObj setEventID:[dict objectForKeyNotNull:@"eventID" expectedObj:@""]];
    [eventObj setEventName:[dict objectForKeyNotNull:@"eventName" expectedObj:@""]];
    [eventObj setEventTimeString:[dict objectForKeyNotNull:@"eventTime" expectedObj:kDefaultTime]];
    [eventObj setEventCreatorID:[dict objectForKeyNotNull:@"eventCreatorID" expectedObj:@""]];
    [eventObj setEventCreatorFName:[dict objectForKeyNotNull:@"firstname" expectedObj:@""]];
    [eventObj setEventCreatorLName:[dict objectForKeyNotNull:@"lastname" expectedObj:@""]];
    [eventObj setEventCreatorName:[NSString stringWithFormat:@"%@ %@",eventObj.eventCreatorFName,eventObj.eventCreatorLName]];
    
    [eventObj setEventCreatorPhoto:[dict objectForKeyNotNull:@"eventCreatorPhoto" expectedObj:@""]];
    [eventObj setEventRSPVed:[dict objectForKeyNotNull:@"eventRSVPed" expectedObj:@"0"]];
    [eventObj setEventDetail:[dict objectForKeyNotNull:@"eventDetail" expectedObj:@""]];
    [eventObj setEventLocation:[dict objectForKeyNotNull:@"eventLocation" expectedObj:@""]];
    [eventObj setEventLattitude:[dict objectForKeyNotNull:@"eventLattitude" expectedObj:@"0.0"]];
    [eventObj setEventLongitude:[dict objectForKeyNotNull:@"eventLongitude" expectedObj:@"0.0"]];
    [eventObj setEventAttendees:[dict objectForKeyNotNull:@"eventAttendees" expectedObj:@"0"]];
    [eventObj setEventAttendeesFriends:[dict objectForKeyNotNull:@"eventAttendeesFriends" expectedObj:@"0"]];
    [eventObj setEventCommentCount:[dict objectForKeyNotNull:@"eventCommentCount"expectedObj:@"0"]];
    [eventObj setIsMyEvent:[dict objectForKeyNotNull:@"isMyEvent" expectedObj:@"0"]];
    [eventObj setEventCategory:[dict objectForKeyNotNull:@"eventCategory" expectedObj:@"0"]];
    [eventObj setEventListFilter:[dict objectForKeyNotNull:@"listFilter" expectedObj:@"0"]];
        
    eventObj.eventFriendList = [NSMutableArray arrayWithArray:[dict objectForKeyNotNull:@"eventFriendList" expectedObj:[NSMutableArray array]]];
    eventObj.eventGroupList = [NSMutableArray arrayWithArray:[dict objectForKeyNotNull:@"eventGroupList" expectedObj:[NSMutableArray array]]];
    
    eventObj.eventCommentList = [[NSMutableArray alloc] init];
    eventObj.eventPhotoList = [[NSMutableArray alloc] init];
    
    [eventObj setEventTime_UI:convertToString([NSDate dateWithTimeIntervalSince1970:eventObj.eventTimeString.floatValue], @"hh:mm a")];
    [eventObj setEventDate_UI:convertToString([NSDate dateWithTimeIntervalSince1970:eventObj.eventTimeString.floatValue], @"MM/dd/yyyy")];
    
    if ([[dict objectForKeyNotNull:@"eventCommentList" expectedObj:[NSArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary* commentDict in [dict objectForKeyNotNull:@"eventCommentList" expectedObj:[NSArray array]]) {
            GWCommentObj *commentObj = [GWCommentObj commentFromDict:commentDict];
            [eventObj.eventCommentList addObject:commentObj];
            commentObj = nil;
        }
    }
    
    if ([[dict objectForKeyNotNull:@"eventPhotoList" expectedObj:[NSMutableArray array]] isKindOfClass:[NSArray class]]) {
        for (NSDictionary* photoDict in [dict objectForKeyNotNull:@"eventPhotoList" expectedObj:[NSArray array]]) {
            GWPhotoObj *photoObj = [GWPhotoObj photoFromDict:photoDict];
            [eventObj.eventPhotoList addObject:photoObj];
            photoObj = nil;
        }
    }
    
    eventObj.k_eventRowCount_Home = 1+(MIN([eventObj.eventCommentCount integerValue], 4))+([eventObj.eventPhotoList count]?1:0);
    eventObj.eventAttendeesFriends = (eventObj.eventAttendeesFriends.length)?eventObj.eventAttendeesFriends:@"0";
    NSString *attendeeStr = nil;
    if (eventObj.eventAttendees.integerValue == 0) {
        attendeeStr = @"0 People | 0 Friends";
    }else if (eventObj.eventAttendees.integerValue == 1){
        attendeeStr = [NSString stringWithFormat:@"1 Person | %@ Friend",eventObj.eventAttendeesFriends];
    }else{
       attendeeStr = [NSString stringWithFormat:@"%@ People | %@ Friend%@",eventObj.eventAttendees,eventObj.eventAttendeesFriends,(eventObj.eventAttendeesFriends.integerValue>1)?@"s":@""];
    }
    eventObj.k_eventAttendeeTotal = attendeeStr;
    
    eventObj.k_uiarray = [eventObj getUIArray];
    
    CGSize sizeDetail = [[NSString stringWithFormat:@"%@\n\n%@",eventObj.eventDetail,eventObj.eventLocation] sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0] constrainedToSize:CGSizeMake(300, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
    
    eventObj.k_rowMinHeight_EventDetail =  MIN(kDetailHeightMin, sizeDetail.height+5);
    eventObj.k_rowFullHeight_EventDetail =  sizeDetail.height+15;

    CGSize sizeName = [eventObj.eventName sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaBoldWithSize:14.0] constrainedToSize:CGSizeMake(300, MAXFLOAT) lineBreakMode:NSLineBreakByCharWrapping];
    eventObj.k_rowHeight_EventName =  MAX(10, sizeName.height+5);
    
    eventObj.eventFullDateString = convertToString([NSDate dateWithTimeIntervalSince1970:[eventObj.eventTimeString floatValue]], @"MMMM dd 'at' hh:mm a");
    eventObj.eventTimeRemainString = [eventObj getTimeRemaining:(eventObj.eventTimeString)];
    
    CGSize eventTimeWidth = [eventObj.eventTimeRemainString sizeWithFont:[[GWAppSettings sharedInstance] app_HelveticaRegularWithSize:14.0] constrainedToSize:CGSizeMake(MAXFLOAT, 35.0) lineBreakMode:NSLineBreakByWordWrapping];
    eventObj.k_eventTimeWidth_Home = eventTimeWidth.width;
    
    return eventObj;
}

/**
 **Returns an array with objects in order that are appearing on home feed screen
 **/
-(NSMutableArray*)getUIArray{
    NSMutableArray *array = [[NSMutableArray alloc] init];
    
    if ([self.eventCommentCount integerValue]>3) {
        GWBaseObj *base = [[GWBaseObj alloc] init];
        [base setType:GwObject_AllComment];
        [array addObject:base];
    }
    for (GWCommentObj *obj in self.eventCommentList) {
        [array addObject:obj];
    }
 
    if ([self.eventPhotoList count]>0) {
        GWBaseObj *base = [[GWBaseObj alloc] init];
        [base setType:GWObject_Photo];
        [array addObject:base];
    }
    return array;
}

-(NSString*)getTimeRemaining:(NSString*)timeStampString{
    NSString *_timeElapsed = nil;
    
    NSTimeInterval noOfSec = [[NSDate dateWithTimeIntervalSince1970:timeStampString.doubleValue] timeIntervalSinceNow];
    float sec = (noOfSec<0)?-(noOfSec):noOfSec;
    
    int days = floor(sec / (60 * 60 * 24));
    sec -= days * (60 * 60 * 24);
    
   int hours = floor(sec / (60 * 60));
    sec -= hours * (60 * 60);
    
   int minutes = floor(sec / 60);
    sec -= minutes * 60;
    
    
        if (days == 0) {
            if (hours == 0) {
                _timeElapsed = [NSString stringWithFormat:@"%d Min",abs(minutes)];
            }
            else{
                if (noOfSec>0)
                    _timeElapsed = [NSString stringWithFormat:@"%d Hour%@ %d Min",hours,(hours>1)?@"s":@"",minutes];
                else
                    _timeElapsed = [NSString stringWithFormat:@"%d Hour%@",hours,(hours>1)?@"s":@""];

            }
        }
        else{
            _timeElapsed = [NSString stringWithFormat:@"%d Day%@",days,(days>1)?@"s":@""];
        }

    
    NSString *finalString = nil;
    if (noOfSec>0) {
        finalString = [NSString stringWithFormat:@"In %@",_timeElapsed];
    }else{
        if (days == 0) {
            finalString = [NSString stringWithFormat:@"Started %@ Ago",_timeElapsed];
        }
        else if (days < 2){
            finalString = [NSString stringWithFormat:@"Yesterday"];
        }
        else{
            finalString = [NSString stringWithFormat:@"%@ Ago",_timeElapsed];
        }
    }
    
    return finalString;
}


-(NSDictionary*)requestDictForEventFomObj:(GWEventObj*)eventObj{
    NSMutableDictionary *requestDict = [[NSMutableDictionary alloc] init];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:eventObj.eventName forKey:@"eventName"];
    [dict setObject:eventObj.eventTimeString forKey:@"eventTime"];
    [dict setObject:eventObj.eventCreatorID forKey:@"eventCreatorID"];
    [dict setObject:eventObj.eventDetail forKey:@"eventDetail"];
    [dict setObject:eventObj.eventLocation forKey:@"eventLocation"];
    [dict setObject:eventObj.eventCategory forKey:@"categoryFilter"];
    [dict setObject:eventObj.eventListFilter forKey:@"listFilter"];
    
    [requestDict setObject:dict forKey:@"eventDetail"];
    [requestDict setObject:eventObj.eventFriendList forKey:@"eventFriendList"];
    [requestDict setObject:eventObj.eventGroupList forKey:@"eventGroupList"];
    
    return requestDict;    
}

- (BOOL)isEqual:(GWEventObj*)anObject
{
    if([self.eventID isEqualToString:anObject.eventID])
        return YES;
    
    return NO;
}

- (NSUInteger)hash
{
    return [self.eventID hash]; //Must be a unique unsinged integer
}

@end
