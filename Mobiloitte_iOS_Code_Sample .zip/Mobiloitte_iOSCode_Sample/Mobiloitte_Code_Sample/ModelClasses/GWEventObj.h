//
//  GWEventObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

#define kDetailHeightMin ((isFourInchDisplay)?140:80)

@interface GWEventObj : GWBaseObj

@property (nonatomic, strong) NSString *eventID;
@property (nonatomic, strong) NSString *eventName;
@property (nonatomic, strong) NSString *eventTimeString;
@property (nonatomic, strong) NSString *eventCreatorID;
@property (nonatomic, strong) NSString *eventCreatorName;
//new added
@property (nonatomic, strong) NSString *eventCreatorFName;
@property (nonatomic, strong) NSString *eventCreatorLName;


@property (nonatomic, strong) NSString *eventCreatorPhoto;
@property (nonatomic, strong) NSString *eventRSPVed;
@property (nonatomic, strong) NSString *eventDetail;
@property (nonatomic, strong) NSString *eventLocation;
@property (nonatomic, strong) NSString *eventLattitude;
@property (nonatomic, strong) NSString *eventLongitude;
@property (nonatomic, strong) NSString *eventAttendees;
@property (nonatomic, strong) NSString *eventAttendeesFriends;
@property (nonatomic, strong) NSString *eventCommentCount;
@property (nonatomic, strong) NSString *isMyEvent;
@property (nonatomic, strong) NSString *eventCategory;
@property (nonatomic, strong) NSString *eventListFilter;
@property (nonatomic, strong) UIImage *eventPhoto;

@property (nonatomic, strong) NSString *eventTime_UI;
@property (nonatomic, strong) NSString *eventDate_UI;

@property (nonatomic, strong) NSString *eventFullDateString;
@property (nonatomic, strong) NSString *eventTimeRemainString;


@property (nonatomic, strong) NSMutableArray *eventCommentList;
@property (nonatomic, strong) NSMutableArray *eventPhotoList;
@property (nonatomic, strong) NSMutableArray *eventFriendList;
@property (nonatomic, strong) NSMutableArray *eventGroupList;

+(GWEventObj*)eventFromDict:(NSDictionary*)dict;

-(NSDictionary*)requestDictForEventFomObj:(GWEventObj*)eventObj;


// properties for UI formatting
@property (nonatomic, readonly) NSInteger k_eventRowCount_Home;
@property (nonatomic, strong, readonly) NSString *k_eventAttendeeTotal;
@property (nonatomic, strong, readonly) NSMutableArray *k_uiarray;
@property (nonatomic, assign, readonly) CGFloat k_rowMinHeight_EventDetail;
@property (nonatomic, assign, readonly) CGFloat k_rowFullHeight_EventDetail;
@property (nonatomic, assign, readonly) CGFloat k_rowHeight_EventName;
@property (nonatomic, assign, readonly) CGFloat k_eventTimeWidth_Home;

@end
