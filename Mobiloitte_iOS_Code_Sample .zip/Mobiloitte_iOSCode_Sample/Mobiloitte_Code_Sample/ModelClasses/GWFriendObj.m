//
//  GWFriendObj.m
//  Demo!
//
//  Created by Apoorve Tyagi on 9/17/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "GWFriendObj.h"

@implementation GWFriendObj

+(GWFriendObj*)friendFromDict:(NSDictionary*)dict{
    GWFriendObj *frnd = [[GWFriendObj alloc] init];
    [frnd setUserID:[dict objectForKeyNotNull:@"userID" expectedObj:@""]];
    [frnd setUserFName:[dict objectForKeyNotNull:@"firstname" expectedObj:@""]];
    [frnd setUserLName:[dict objectForKeyNotNull:@"lastname" expectedObj:@""]];
    [frnd setUserName:[NSString stringWithFormat:@"%@ %@",frnd.userFName,frnd.userLName]];
    
    [frnd setUserPhotoURL:[dict objectForKeyNotNull:@"userPhoto" expectedObj:@""]];
    [frnd setUserPhoneNo:[dict objectForKeyNotNull:@"mobileNumber" expectedObj:@""]];
    [frnd setMutualFriendCount:[dict objectForKeyNotNull:@"mutualFriendCount" expectedObj:@"0"]];
    [frnd setMutualFriendCount_Text:([frnd.mutualFriendCount integerValue])?[NSString stringWithFormat:@"%@ mutual friends",frnd.mutualFriendCount]:@""];
    [frnd setIsMyFriend:[dict objectForKeyNotNull:@"isMyFriend" expectedObj:@"0"]];
    
    [frnd setIsSelected:@"0"];
    return frnd;
}

@end
