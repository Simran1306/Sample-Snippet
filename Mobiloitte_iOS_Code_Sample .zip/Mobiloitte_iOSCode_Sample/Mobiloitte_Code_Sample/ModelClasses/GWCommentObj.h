//
//  GWCommentObj.h
//  Demo!
//
//  Created by Apoorve Tyagi on 8/26/13.
//  Copyright (c) 2013 Halosys Technologies. All rights reserved.
//

#import "Macros.h"

@interface GWCommentObj : GWBaseObj

@property (nonatomic, strong) NSString *userID;
@property (nonatomic, strong) NSString *userName;

@property (nonatomic, strong) NSString *userFName;
@property (nonatomic, strong) NSString *userLName;


@property (nonatomic, strong) NSString *userPhoto;
@property (nonatomic, strong) NSString *userComment;
@property (nonatomic, strong) NSString *commentTime;
@property (nonatomic, strong) NSString *commentTime_UI;


@property (nonatomic, readonly) CGFloat k_rowSize_Home;
@property (nonatomic, readonly) CGFloat k_rowSize_Comment;


+(GWCommentObj*)commentFromDict:(NSDictionary*)dict;

@end
