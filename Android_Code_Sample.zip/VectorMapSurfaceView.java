
import java.util.ArrayList;
import java.util.HashMap;

import android.annotation.TargetApi;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.os.Build;
import android.os.Vibrator;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.ScaleGestureDetector.OnScaleGestureListener;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class VectorMapSurfaceView extends SurfaceView implements Runnable
{
	public static String LOG_TAG = "WorldMap";

	private Context mContext;
	private Thread mThread = null;
	private SurfaceHolder mSurfaceHolder;
	private volatile boolean mRunning = false;
	private WorldMap mWorldMap;
	private ScaleGestureDetector mScaleDetector;
	private GestureDetector mGestureDetector;
	private boolean mIsTouchable; // Sets whether this view is touchable or not. Useful for disabling it while loading data.

	// Book-keeping for pan/zoom actions
	private float mScale; // The current scale of the map
	private float mLastFocusX; // Scaling focal point
	private float mLastFocusY; // Scaling focal point
	private Matrix mDrawMatrix; // Matrix used for drawing and inverse-transformation for hit-testing points
	private Matrix mBufferMatrix; // Buffer matrix for intermediate operations

	// Flinging support
	private float mSpeedX;
	private float mSpeedY;

	// Progress bar
	private ProgressDialog mProgressBar;

	// The callbacks for user action
	MapEventListener mMapEventListener;

	/**
	 * Implementation of this interface must handle the actions of users on the
	 * WorldMap.
	 * 
	 */
	public interface MapEventListener
	{
		/**
		 * Called when user requests to load the top users for the city
		 * specified by cityId
		 * 
		 * @param cityId The city id for which the user asked to get top users
		 */
		public void onRequestLoadCityTopUsers(Integer cityId);

		/**
		 * Called when user requests to load the city data for the list of
		 * countries specified by countryId. The return value is expected to be
		 * a list of city IDs belonging to the specified countries alongside
		 * their top users data.
		 * 
		 * @param countryId  The country for which the user asked to load city data
		 * @return a list of city IDs belonging to the specified country alongside their users data.
		 */
		public HashMap<Integer, Float> onRequestLoadCountryData(int countryId);

		/**
		 * Action fired when user starts multi-selection mode.
		 * @param countryId The country ID on which the user triggered multi-selection mode.
		 * Will be assigned a value of -1 if no country is selected.
		 */
		public void onMultiSelectionStarted(int countryId);

		/**
		 * Action is fired when the user changes the set of multi-selected countries.
		 * @param counryIds The IDs of the selected countries (COPIED from map)
		 */
		public void onMultiSelectionChanged(ArrayList<Integer> counryIds);
	}

	public VectorMapSurfaceView(Context context)
	{
		super(context);
		init(context);
	}

	public VectorMapSurfaceView(Context context, AttributeSet attrs)
	{
		super(context, attrs);
		init(context);
	}

	public VectorMapSurfaceView(Context context, AttributeSet attrs, int defStyle)
	{
		super(context, attrs, defStyle);
		init(context);
	}

	@TargetApi(Build.VERSION_CODES.HONEYCOMB)
	private void init(Context context)
	{
		mContext = context;
		mScale = 1.0f;
		mLastFocusX = 0;
		mLastFocusY = 0;
		mDrawMatrix = new Matrix();
		mBufferMatrix = new Matrix();
		mSurfaceHolder = getHolder();
		mSpeedX = 0f;
		mSpeedY = 0f;
		mIsTouchable = true;

		mProgressBar = new ProgressDialog(context);
		mProgressBar.setCancelable(false);
		mProgressBar.setMessage("Loading data...");
		mProgressBar.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		mProgressBar.setProgress(0);
		mProgressBar.setMax(100);

		mScaleDetector = new ScaleGestureDetector(context, new OnScaleGestureListener() {
			@Override
			public void onScaleEnd(ScaleGestureDetector detector)
			{

			}

			@Override
			public boolean onScaleBegin(ScaleGestureDetector detector)
			{
				mLastFocusX = detector.getFocusX();
				mLastFocusY = detector.getFocusY();
				return true;
			}

			@Override
			public boolean onScale(ScaleGestureDetector detector)
			{
				float focalX = detector.getFocusX();
				float focalY = detector.getFocusY();
				float focalShiftX;
				float focalShiftY;
				float scaleFactor = detector.getScaleFactor();

				mBufferMatrix.reset();

				// Zoom around focal point
				mBufferMatrix.postTranslate(-focalX, -focalY);

				// Constraint zoom
				if (mScale * scaleFactor > Config.ZOOM_MIN && mScale * scaleFactor < Config.ZOOM_MAX)
				{
					mScale *= scaleFactor;
					mBufferMatrix.postScale(scaleFactor, scaleFactor);
				}

				focalShiftX = focalX - mLastFocusX;
				focalShiftY = focalY - mLastFocusY;

				mBufferMatrix.postTranslate(focalX + focalShiftX, focalY + focalShiftY);
				mDrawMatrix.postConcat(mBufferMatrix);

				mLastFocusX = focalX;
				mLastFocusY = focalY;

				return true;
			}
		});

		mGestureDetector = new GestureDetector(context, new GestureDetector.OnGestureListener() {

			@Override
			public boolean onSingleTapUp(MotionEvent e)
			{
				// Get the point in reverse transform
				PointF point = reverseTransform(e.getX(), e.getY());
				mWorldMap.highlight(point, mScale);

				// In case we are in multi-selection mode, inform listeners
				if(mWorldMap.isMultiSelectionMode)
					mMapEventListener.onMultiSelectionChanged((ArrayList<Integer>)mWorldMap.getHighlightedCountries().clone());

				return true;
			}

			@Override
			public void onShowPress(MotionEvent e)
			{

			}

			@Override
			public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY)
			{
				/*
				 * // Get the non-transformed map bounds RectF mapBounds =
				 * mWorldMap.getBoundingBox();
				 * 
				 * // Compute new bounds after scrolling float[] pts = new
				 * float[]{mapBounds.left - distanceX, mapBounds.top -
				 * distanceY, mapBounds.right - distanceX, mapBounds.bottom -
				 * distanceY};
				 * 
				 * // Map the points to the current transform
				 * mDrawMatrix.mapPoints(pts);
				 * 
				 * if(pts[0] > 0 || pts[2] <
				 * VectorMapSurfaceView.this.getWidth()) distanceX = 0;
				 * 
				 * if(pts[1] > VectorMapSurfaceView.this.getHeight() - 20 ||
				 * pts[3] < 20 ) distanceY = 0;
				 */

				mDrawMatrix.postTranslate(-distanceX, -distanceY);
				return true;
			}

			@Override
			public void onLongPress(MotionEvent e)
			{
				// Do not detect long press when we are in multi-selection mode
				if (mWorldMap.isMultiSelectionMode)
					return;

				// No long press detection for more than one finger, fix for
				// some version
				if (e.getPointerCount() > 1)
					return;

				// Transform the hit-point
				PointF point = reverseTransform(e.getX(), e.getY());

				// Inform the world map
				mWorldMap.startMultiSelectionMode(point, mScale);

				if(mWorldMap.getHighlightedCountries().size() > 0)
				{
					// Inform listeners
					mMapEventListener.onMultiSelectionStarted(mWorldMap.getHighlightedCountries().get(0));
				}
				else
				{
					// Inform listeners
					mMapEventListener.onMultiSelectionStarted(-1);
				}

				// Vibrate for some time
				Vibrator v = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
				v.vibrate(100);
			}

			@Override
			public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY)
			{
				mSpeedX = velocityX / 50f;
				mSpeedY = velocityY / 50f;

				return false;
			}

			@Override
			public boolean onDown(MotionEvent e)
			{
				return true;
			}
		});

		GestureDetector.OnDoubleTapListener doubleTapListener = new GestureDetector.OnDoubleTapListener() {

			@Override
			public boolean onSingleTapConfirmed(MotionEvent e)
			{
				return false;
			}

			@Override
			public boolean onDoubleTapEvent(MotionEvent e)
			{
				return false;
			}

			@Override
			public boolean onDoubleTap(MotionEvent e)
			{
				// No double-tap hanling on multi selection mode
				if (mWorldMap.isMultiSelectionMode)
					return false;

				// Check if there's a country beneath the user's
				// selection
				PointF point = reverseTransform(e.getX(), e.getY());
				mWorldMap.highlight(point, mScale);

				int countryId = mWorldMap.getSelectedCountry();
				int cityId = mWorldMap.getSelectedCity();

				if (countryId != -1)
				{
					// Disable this view
					mIsTouchable = false;

					// Start progress
					mProgressBar.show();

					// Load the city data
					HashMap<Integer, Float> cityData = mMapEventListener.onRequestLoadCountryData(countryId);
					mWorldMap.setCitiesPopulation(cityData);

					// End progress
					mProgressBar.dismiss();

					// Enable view
					mIsTouchable = true;
				}
				else if (cityId != -1) // Maybe a user has double tapped on a city?
				{
					// Inform listeners that the user requested the top users for a city
					mMapEventListener.onRequestLoadCityTopUsers(cityId);
				}

				return false;
			}
		};

		mGestureDetector.setOnDoubleTapListener(doubleTapListener);
	}

	public void setCitiesPopulation(HashMap<Integer, Float> cityData)
	{
		mWorldMap.setCitiesPopulation(cityData);
	}

	/**
	 * Ends the multi-selection mode on this vector map.
	 */
	public void endMultiSelectionMode()
	{
		this.endMultiSelectionMode(null);
	}

	/**
	 * Ends the multi-selection mode on this vector map; setting the city data to the provided hashmap.
	 * @param cityData The city data to provide to the map. If null is passed, the map is reset to initial state.
	 */
	public void endMultiSelectionMode(HashMap<Integer, Float> cityData)
	{
		if(cityData != null)
		{
			// Feed the city data to the map
			mWorldMap.setCitiesPopulation(cityData);
		}

		// Inform map about ending multi-selection mode
		mWorldMap.endMultiSelectionMode();
	}

	/**
	 * Sets the countries data to the specified values
	 * 
	 * @param cdata A list of country IDs and their corresponding user data obtained from SnM service
	 */
	public void setCountriesData(HashMap<Integer, Float> cdata)
	{
		mWorldMap = new WorldMap(mContext);

		// Center map to screen
		float screenWidth = mContext.getResources().getDisplayMetrics().widthPixels;
		float screenHeight = mContext.getResources().getDisplayMetrics().widthPixels;

		mDrawMatrix.setTranslate(screenWidth / 2f - WorldMap.DIP_WIDTH * Config.DENSITY / 2f, screenHeight / 2f
				- WorldMap.DIP_HEIGHT * Config.DENSITY / 2f);

		mWorldMap.setCountriesPopulation(cdata);
	}

	@Override
	public void onWindowFocusChanged(boolean hasFocus)
	{
		super.onWindowFocusChanged(hasFocus);

		// Update width and height of container on world map
		mWorldMap.setContainerDimensions(this.getWidth(), this.getHeight());
	}

	@Override
	public boolean onTouchEvent(MotionEvent event)
	{
		// Do not receive touches when we are disabled
		if (!mIsTouchable)
			return false;

		mScaleDetector.onTouchEvent(event);

		if (!mScaleDetector.isInProgress())
			mGestureDetector.onTouchEvent(event);

		return true;
	}

	/**
	 * Sets the internal map event listener to the specified listener
	 * 
	 * @param listener The MapEventListener implmenentation
	 */
	public void setMapEventListener(MapEventListener listener)
	{
		mMapEventListener = listener;
	}

	public void onResumeMySurfaceView()
	{
		mRunning = true;
		mThread = new Thread(this);
		mThread.start();
	}

	public void onPauseMySurfaceView()
	{
		boolean retry = true;
		mRunning = false;
		while (retry)
		{
			try
			{
				mThread.join();
				retry = false;
			}
			catch (InterruptedException e)
			{
				e.printStackTrace();
			}
		}
	}

	/**
	 * Applies an inverse matrix transformation on the provided coords.
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	private PointF reverseTransform(float x, float y)
	{
		float[] pts = new float[] { x, y };
		Matrix inversed = new Matrix();

		if (mDrawMatrix.invert(inversed))
		{
			inversed.mapPoints(pts);
		}

		return new PointF(pts[0], pts[1]);
	}

	@Override
	public void run()
	{
		while (mRunning)
		{
			if (mSurfaceHolder.getSurface().isValid())
			{
				Canvas canvas = mSurfaceHolder.lockCanvas();

				// Add some flinging, exponential drop-off
				if (mSpeedX > 0f || mSpeedY > 0f)
				{
					mDrawMatrix.postTranslate(mSpeedX, mSpeedY);

					mSpeedX /= Config.FLING_FACTOR;
					mSpeedY /= Config.FLING_FACTOR;
				}

				canvas.setMatrix(mDrawMatrix);
				mWorldMap.drawOn(canvas);

				mSurfaceHolder.unlockCanvasAndPost(canvas);
			}
		}
	}

}
